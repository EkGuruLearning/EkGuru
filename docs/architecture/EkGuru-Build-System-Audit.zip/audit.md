# EkGuru — Build System Migration Audit and Approval Proposal

**Date:** 2026-11-24. **Repository:** EkGuruLearning/EkGuru. **Branch:** arena/5aa71e50-ekguru. **HEAD:** d9aeb63316f780bcc686a65655f09be06c8ea5a3.

**Status: READ-ONLY AUDIT COMPLETE AS A STATIC DISPOSITION LEDGER. MIGRATION NOT IMPLEMENTED.** This is a deliberately conservative, two-file migration proposal—not permission to relocate every generator. Unresolved runtime/import contracts have KEEP or DEFER decisions, not speculative destinations. Approval must be explicit and limited to this tranche. Validation is designed below, not claimed executed.

## How to read the evidence

The accompanying ledger classifies **448 files**: all **425 tools files**, **14 marketing scripts**, **2 root scripts**, **6 workflow files**, and **package.json**. Within tools: **236 nonlauncher root code files + 22 existing launchers + 24 library files + 1 indexing contract + 133 protected content files + 9 other inputs/assets/docs = 425**. These categories do not double-count. The root candidates are `sw.js` and `playwright.config.mjs`; no root Python/shell generator exists in the current working tree.

`audit-ledger.json` contains one record per file, including exact source SHA-256, responsibility, imports, dynamic/exec sites, exports, main guards, caller/reference evidence with paths and lines, write-sink candidates, path literals, CWD/root/sibling assumptions, remote-service/URL evidence, publication classification, exact proposed path, decision, risk and reasons. `path-map.csv` is the exact old→proposed map. The interactive HTML exposes every record; the bundle includes the full audited text sources for independent line-level review.

References distinguish **resolved imports/loaders**, **literal interpreter command vectors**, and **text mentions**. A filename in documentation or a generated header is not an executable caller. A URL string is not itself a network operation. Receiver-typed operations and computed paths can remain unresolved. Static extraction does not prove the absence of arbitrary computed names, out-of-repository callers, reflection or transitive effects. Those uncertainties have not been converted into MOVE decisions. A DEFER row's proposed path equals its current path; it does not authorize a later move. Documentation mentioning older filenames remains historical evidence, not a current instruction.

No target script was imported or executed for this audit. Repository source was read as text/AST only. No dependency installation, build, test, live request, GitHub operation, staging or deployment occurred. Audit deliverables were created only under `/tmp/ekguru-build-audit`, outside the checkout. The source snapshot is the **current dirty worktree**, including previous restructuring and the SEO correction, not HEAD alone.

## A. Recommended final directory structure

Use the already private `tools/` boundary; do not create a root build tree. The only new implementation directory in this tranche is:

```text
tools/
  pipeline/
    assets/
      bundle-experience-css.py   # canonical implementation, proposed move
      build-dark-fix.py          # canonical implementation, proposed move
  bundle-experience-css.py       # proposed compatibility adapter, same legacy CLI/API
  build-dark-fix.py              # proposed compatibility adapter, same legacy CLI/API
  build-all.py                  # unchanged ordered orchestration
  build-public-dist.py          # unchanged protected publisher
  build-runtime.mjs             # unchanged runtime compilation/header contract
  lib/                          # all 24 files retained
  assets/og-fonts/               # fonts and licence retained
  templates/                    # retained HTML template input
  ultra/contract.py             # retained immutable indexing contract
  [eight protected content subtrees, all 133 files unchanged]
  [all other KEEP / DEFER files and 22 existing test launchers unchanged]
_site/                          # unchanged artifact destination; not a new source tree
src/runtime/voice.js             # unchanged source
js/voice.js                      # unchanged browser output
sw.js                           # unchanged browser service worker
.github/workflows/               # paths retained; only additive CI compatibility test
```

The exhaustive candidate tree follows in the appendix. No empty `site`, `content`, `seo`, `validation`, `shared`, `integrations`, `public` or root `build` placeholders are proposed. Those may look tidy but would exceed the proven migration scope.

### Publisher policy verification

The actual `PRIVATE_DIRS` literal in `tools/build-public-dist.py` contains `tools` and `docs`, and **does not contain `build`**. Both proposed paths begin with `tools/` and are therefore private under the unchanged current rules. Marketing sources remain under excluded `docs/`. `playwright.config.mjs` and package files are private root files; `sw.js` is public runtime. No publisher predicate was imported/executed or changed; this conclusion comes from its source and literal exclusions. Other scanners use different boundaries: private-for-Pages does not mean ignored-by-every-inventory. Moving only Python tooling beneath an already excluded tools ancestor avoids moving any HTML source or changing output discovery paths.

## B. Exact old→proposed path map

Only these implementations move:

| Current implementation | Proposed implementation | Old-path disposition | Risk |
|---|---|---|---|
| tools/bundle-experience-css.py | tools/pipeline/assets/bundle-experience-css.py | Retain compatibility adapter | MEDIUM |
| tools/build-dark-fix.py | tools/pipeline/assets/build-dark-fix.py | Retain compatibility adapter | MEDIUM |

Every other current path maps **to itself**, explicitly enumerated in the 448-row appendix and CSV. An existing test launcher's `compatibility_target` identifies its already-canonical test, not a newly proposed move.

### MOVE 1 — CSS experience bundler

Responsibility: compact `css/experience.css` and replace only the `EKGURU_EXPERIENCE_BUNDLED` block in `css/style.min.css`. Reads the existing output as input so unrelated blocks must survive. Imports: `os`, `re`, `sys` only. No dynamic imports, subprocesses, sibling loads or remote-service calls. Current ROOT is derived from two dirname operations; import performs `os.chdir(ROOT)`.

Known executable callers: `tools/build-all.py:177` (`--check`) and `:292` (write mode), through literal Python command vectors. No detected repository package, workflow-direct, module-import or runpy caller. CI reaches it transitively through build-all. Known external mentions: `docs/DESIGN-SYSTEM.md:260,328`, `css/experience.css:5,5967`, `reports/PHASE9-FLASHCARDS.md:63`, `reports/USABILITY-HOME-24.md:278`. None requires editing when the old path remains supported.

Local write: `open(BUNDLE, 'w', encoding='utf-8')` at line 144; target is `css/style.min.css`. `--check` returns 1 if stale and does not take that write branch. Normal write mode must preserve exact compaction, whitespace, marker and stale-message behavior.

API to preserve: imported names and module constants, notably `ROOT` (str), `SRC`, `BUNDLE`, `START`, `END`, and functions `strip_comments`, `compact`, `_strip_combinator_space`, `build_block`, `main`. In particular, the calc/combinator whitespace behavior is not an opportunity for refactoring.

### MOVE 2 — dark/contrast override builder

Responsibility: derive overrides from the exact fixed `SOURCES` list and replace the `EKGURU_DARK_FIX` block in `css/style.min.css`. Imports: `__future__.annotations`, `re`, `sys`, `pathlib.Path` only. No dynamic imports, sibling loads, subprocesses or remote calls. Uses an absolute `ROOT` Path; does not change CWD.

Known executable callers: `tools/build-all.py:178` (`--check`) and `:293` (write mode). No detected package, workflow-direct, documentation, test-import or runpy caller. CI is transitive through build-all. Local write: `BUNDLE.write_text(new, encoding='utf-8')` at line 339. `--check` detects staleness without writing.

Preserve all constants and regexes, including `ROOT` (Path), `BUNDLE`, `START`, `END`, `SOURCES`, `DARK_SCOPE`, `HEX`, `SKIP_SEL`, `PAGE_SEL`, `LINK_SEL`; and functions `css_from_js`, `strip_comments`, `parse_rules`, `luminance_of_hex`, `colour_lum`, `colour_sat`, `declarations`, `scope_one`, `scope`, `build_block`, `main`. No thresholds, selectors, colour rules, filenames or fallbacks change.

## C. Explicit KEEP decisions

The appendix lists every KEEP with individual evidence and reason. Important fixed interfaces include:

- `tools/build-public-dist.py`, `_site/` behavior and `.github/workflows/pages.yml`: retain deployment architecture.
- `tools/ultra/contract.py` and `data/quality/indexing-baseline.json`: retain original Git-object/indexing contract; never restore/recapture the baseline during migration.
- `tools/build-runtime.mjs`, `src/runtime/voice.js`, `js/voice.js`: retain minifier/header/budget/output bytes.
- `tools/build-all.py`, `tools/run-phase7c-pipeline.py`: keep CLI and operational ordering. Existing diagnostic exit/report limitations are not repaired in this phase.
- `tools/build-sitemaps.py`, `tools/build-search-index.py`, `tools/discovery_integrity.py`: retain publication/discovery paths and parser/API coupling.
- All 24 `tools/lib/` files: retain import topology (`lib.*`, `tools.lib.*`, bare-name/sys.path variants), authored banks and mixed JS/Python consumers. A shared directory does not prove generic utility status.
- All 133 files in the eight protected content subtrees: retained without migration or semantic content audit.
- Root authored modules/banks (`hindi-foundation-content.py`, `hindi-halfsteps-content.py`, `materials_b.py`, `materials_c.py`, langpack sources), DSL helpers and their consumer contracts: retained; no deduplication proposed.
- Tutor feed/generation/roster scripts, Sheet fetch/sync, Apps Script sources and assembly, mail/questions backends, advertising/consent injectors and advertising-launch checks: retain integration/public behavior.
- `sw.js`, all public directories, source/runtime/browser files and URLs: not relocated or regenerated.

Payments, bookings, tutor intake, Telegram, provider configuration, AdSense/account state, consent behavior, course material/answers/progress, TTS/SRS/offline/search/schema/accessibility remain outside implementation scope. Source references are evidence only; this audit neither verifies production nor authorizes service access.

## D. Compatibility launcher and API-preservation plan

### Existing 22 launchers

Retain them byte-for-byte. Each existing mapping is in the ledger and a dedicated table below. ESM launchers import their canonical `.mjs` test; CommonJS launchers require their canonical `.js` test; the Python launcher delegates with the current Python interpreter, forwards arguments and exits with the child status. Do not replace these mechanisms in this tranche. Their canonical tests and all original assertions stay unchanged.

### Two proposed adapters

Do **not** use a subprocess-only launcher or simply call canonical `main()`: that would drop functions/constants and potentially change CWD/import semantics. Use one implementation body, not a second maintained copy.

Recommended design: a small Python adapter executes the canonical source, compiled with `dont_inherit=True`, in the legacy module's **own globals dictionary**, retaining `__name__`, loader/spec and module identity. Temporarily set `__file__` to the canonical implementation during execution so its corrected ROOT calculation resolves the repository; restore the legacy `__file__` afterward and remove adapter-private helper names. Source review finds `__file__` used only to derive ROOT in the two candidates, not later in their functions. Function `__globals__` must remain the legacy module namespace, so monkeypatching `SRC`, `BUNDLE`, `ROOT` or `SOURCES` has the same effect as before. Do not use `globals().update(runpy.run_path(...))`: functions would retain a different globals dictionary.

The canonical implementations remain directly executable and importable by file path. Adjust **only** their root-location expressions: the new file depth requires repository `parents[3]` rather than `parents[1]`; preserve the bundler's str ROOT, dark builder's Path ROOT and original CWD behavior. Do not change the output/stale messages' legacy commands, generated CSS markers, or any processing algorithm. Physical source location/traceback filenames necessarily differ for moved implementation code; no detected caller depends on the original code filename. If the isolated compatibility tests expose such a dependency, do not waive it—KEEP that implementation at its original path instead.

Python CLI, normal import, `spec_from_file_location` + `exec_module`, `runpy.run_path` with default/custom/main run names, arguments, SystemExit values, globals mutation and import-time CWD effects all require explicit equivalence tests. No ordinary Python package-import renaming is proposed. No Node module moves are proposed.

Registration: keep the completed cleanup manifest and its historical original hashes/22 launcher count unchanged. Add a **separate future** build-system path/compatibility registry documenting these two moves, pre-move hashes, old/new paths, wrapper kind and API obligations. A candidate location is `docs/architecture/build-system-path-map.json` with an accompanying build-system decision record. These files do not exist and have not been created in the repository. Do not silently append new test-launcher entries to the completed cleanup phase or change its 197 original mappings.

## E. Required reference and registration updates

For this exact two-implementation tranche (plus the explicit additive support-file allowlist below):

| Surface | Required action after approval |
|---|---|
| package.json, all 16 scripts | NONE. No new generic build script; existing commands remain supported. Full script values are in the ledger. |
| ci.yml | Preserve every existing command and assertion. Add one offline step before the master check: `python3 -B tests/unit/test-build-system-compatibility.py`. No new dependency or live access. |
| pages.yml | NONE; Python 3.12 publisher/check/artifact path/deploy sequence unchanged. |
| course-health.yml | NONE; preserve health/language gate and issue behavior. Do not execute issue creation. |
| live-guard.yml | NONE; preserve live probes/guard commands. Do not execute remote probes. |
| playwright.yml | NONE; preserve Playwright test/config paths and browser setup. |
| sheet-sync.yml | NONE; preserve live bake, tutor operations, metadata/index/inventory order and write/commit behavior. Never execute that workflow in the audit checkout. |
| tools/build-all.py | Recommend no command changes: retain bundle calls at 177/292 and dark calls at 178/293, in original order. Canonical-path registration can be documented without changing execution. |
| docs/DESIGN-SYSTEM.md | No required edit at 260/328: legacy commands remain valid. Optional architecture note only, in a new phase-specific document. |
| css/experience.css | NONE; do not edit public source comments just to rename a still-valid command. |
| reports/PHASE9-FLASHCARDS.md and reports/USABILITY-HOME-24.md | NONE; preserve historical evidence. |
| Existing test files and 22 launchers | NONE to assertions/expectations/paths. Add separate tests for new canonical/legacy equivalence, not replacement tests. |
| New migration evidence/tests | Add proposed build-system registry, compatibility/API tests and isolated-output equality checks after approval. Register the added test entrypoint in the phase-specific validation instructions; do not weaken an existing suite to accommodate it. |

Full detected test/documentation/package/workflow references for **every candidate**, including retained/deferred files, are in its ledger record. Because those paths stay fixed, this tranche requires no global search-and-replace. Existing architecture/handover documents remain protected; do not rewrite their historical plans as migration authorization.

## F. Dependency and pipeline diagrams

This is a dependency/ordering sketch, not a new execution plan:

```mermaid
flowchart TD
  CI[ci.yml] --> CONTRACT[tools/ultra/contract.py]
  CI --> MASTER[tools/build-all.py check]
  CI --> TESTS[Organized unit / regression / integration tests]
  SHEET[sheet-sync.yml - live and write capable] --> SYNC[Sheets / tutor generation - retained]
  MASTER --> SOURCE[World and Indian course / registry builders - retained]
  SOURCE --> ASSETS[Asset layers]
  ASSETS --> BUNDLE[legacy bundle-experience-css.py adapter]
  BUNDLE --> BC[tools/pipeline/assets/bundle-experience-css.py]
  BC --> CSS[css/style.min.css]
  ASSETS --> DARK[legacy build-dark-fix.py adapter]
  DARK --> DC[tools/pipeline/assets/build-dark-fix.py]
  DC --> CSS
  MASTER --> TUTOR[Tutor / page layers / publication controls - retained]
  TUTOR --> MAP[build-sitemaps.py]
  MAP --> SEARCH[build-search-index.py]
  SEARCH --> DISC[discovery_integrity API]
  SEARCH --> COPY[build-copy-index.js]
  COPY --> EDITOR[update-editorial-metadata.py]
  EDITOR --> ULTRA[apply-ultra.py]
  ULTRA --> INV[Full / Phase 2 / Phase 3 inventories]
  INV --> DOCTOR[doctor.js - report/live chain]
  PAGES[pages.yml - separate deployment pipeline] --> PUB[tools/build-public-dist.py]
  PUB --> SITE[_site website-only artifact]
  SITE --> DEPLOY[GitHub Pages artifact upload/deploy - unchanged]
```

The bundler must run before dark-fix in both check/write master branches. They share an output, not interchangeable responsibilities. Neither replaces the other. Pages copies committed/generated website files; it does not run build-all. The larger course → page → index → metadata → inventory pipeline and the sheet-sync-specific strip/reapply order are retained, not redefined by this diagram. `dependency-graph.mmd` additionally lists all resolved local import/file-loader and literal Python command-vector edges from the ledger, without treating every filename mention as an execution edge.

## G. Risk register

| Risk | Evidence | Severity | Mitigation / stop criterion |
|---|---|---|---|
| Tool sources accidentally published | Publisher denies tools, not root build | HIGH | All new implementations stay under tools. Publisher rules unchanged. Artifact inventory and bytes must match. |
| Wrong repo root after nesting | Bundler lines 40–41; dark line 38 derive ROOT from __file__ | HIGH | Change only root-depth expressions, preserve types and CWD effects. Import and CLI tests from repo root, unrelated CWD and paths with spaces. |
| Wrapper loses Python API/globals identity | Both expose helpers/constants; naive main-only or runpy-copy wrappers drop contracts | HIGH | Namespace-preserving execution; export/signature/constants/globals-mutation/runpy tests. Failure means KEEP, not test relaxation. |
| Shared CSS output ordering changes | build-all 177→178 and 292→293; both replace blocks in style.min.css | HIGH | Preserve command order; compare bytes after each step and combined second run. Assert unrelated blocks unchanged. |
| CSS semantics drift under a move | calc whitespace compaction and dark/contrast selection rules are implemented code | HIGH | Original behavior as oracle; adversarial fixture bytes and existing DOM/theme tests, no new thresholds. |
| Private HTML/source enters scanners | Sitemap rglob and other walkers have differing exclusion rules | HIGH | No content/template relocation. Compare page/sitemap inventories as well as publisher set. |
| Historical tools are misclassified unused | Many report/repair/live tools have indirect or no statically resolved callers | HIGH | KEEP/DEFER; never delete, merge or archive automatically. All known references retained. |
| Hidden dynamic import/sibling coupling | importlib, runpy, bare lib/tools.lib imports and filename loaders recorded per file | HIGH | Only two files with no detected such callers move; retain all unresolved contracts at old paths. |
| Accidental live calls or issue/commit actions | Sheet sync, doctor, weekly/live workflows, provider/browser tools | HIGH | No execution now. Isolated future tests with network denial. Live jobs remain Not executed/Blocked pending separate authorization. |
| Prior work overwritten | Current dirty tree contains restructuring and SEO correction, not just HEAD | HIGH | Capture hashes/status of current tree; never reset/stash/clean/checkout old commit to form rollback. |
| Diagnostics reported green just from exit status | Existing reporting/orchestration limitations; doctor may summarize child failures without a failing process exit | HIGH | Evaluate explicit assertions, reports and child outcomes; PASS / FAIL / Not executed / Blocked separately. No fixes bundled. |
| Environment missing dependencies/browser/font renderers | Marketing / Playwright / Puppeteer / Pillow / renderer imports recorded; some absolute /tmp paths | MEDIUM | Retain/defer. No installs or invented successful validation. Test only existing offline environment; otherwise Blocked. |
| Wrapper implementation drift | Two maintained implementation copies could diverge | MEDIUM | One canonical implementation; old path only an adapter, source/API parity test and separate registry. |
| Transient /tmp audit artifacts lost | Deliverables intentionally outside checkout | LOW | Download the delivered bundle. No report persistence is used as permission to create repository files. |

## H. Move-by-move isolated validation design

**All execution in this section is NOT EXECUTED.** Approval authorizes the bounded implementation work, not live services, dependencies, commits or deployment. Use two isolated copies of the **current worktree** outside the working repository: BASELINE and CANDIDATE. Include current untracked canonical files and deletions; copying HEAD would discard the completed work. Keep service access denied and use existing dependencies only. Copy baseline source files with their current hashes before editing the candidate copy.

### H1. CSS bundler, independently

1. Compare baseline vs canonical vs legacy adapter imports in isolated fresh Python processes. Preserve exported functions, signatures, constants and ROOT type/value; verify module globals are used by functions after patching SRC/BUNDLE. Check original import-time chdir, including importlib file loads and runpy default/custom/main names.
2. Run existing `--check` on current and deliberately stale copied CSS. Compare return codes, stdout/stderr and unchanged file hashes. Test malformed/missing marker, empty/unbalanced input and missing files against baseline behavior without rewriting acceptance rules.
3. Run write mode in each copy with identical starting files. Compare **every changed path and exact byte content**, including marker newlines and unrelated CSS. Re-run and require byte stability against baseline; do not accept output normalization.
4. Compare compaction function outputs on calc(), nested parentheses, selectors/combinators and existing source fixtures; retain existing behavior even if unrelated flaws are noticed.
5. Run baseline/canonical/legacy commands from an unrelated CWD and with arguments unchanged. No new library imports or subprocess execution should be introduced into the canonical processor.

### H2. Dark/contrast builder, independently

1. Fresh-process baseline/canonical/legacy import and runpy equivalence, all helpers/constants/regex flags and exact SOURCES ordering, monkeypatched ROOT/BUNDLE/SOURCES semantics, and absence of import-time CWD change.
2. Compare `--check` with current and stale output: exit values, streams, no writes. Normal mode: exact byte equality, marker replacement/tail preservation and second-run stability against baseline.
3. Exercise baseline-defined light/dark/tinted values, contrast and dark scopes, media/supports contexts, existing generated-block exclusion, calc/string CSS input, missing optional source files and malformed markers. No thresholds/selectors/expected failures may be changed.
4. Evaluate all current fixed sources identically; no public JS input is rewritten. Only the stylesheet output is permitted to change in isolated fixture runs, and its bytes must equal the baseline run.

### H3. Combined ordered pipeline and API discovery

Run bundle → dark in each isolated copy, matching build-all order. Compare output after each command and after a second combined run, rather than claiming all possible CSS transformations commute. Re-scan references/import edges and validate both registered implementation paths plus legacy adapters. Do not execute build-all wholesale merely because its subcommands carry --check: some other children write reports or reach services. Run broader orchestrators only in a separately authorized isolated/offline harness with unchanged semantics; otherwise mark them Blocked.

### H4. Node imports and package scripts

No Node source/module/entrypoint moves are proposed. Verify their current paths and relative require/import graph remain unchanged; test the two legacy Python entrypoints through their existing Node/Python callers where applicable. Enumerate all 16 package scripts from the ledger. For each, record invocation, dependency availability, remote-service capability, exit and explicit test assertions. Run offline-safe suites only in isolated copies with existing dependencies; do not stub remote success, skip assertions, install packages or label a blocked network suite PASS. `npm start` is a long-running server, not a unit-test gate. Advertising status/check are diagnostics with policy outputs, not proof of live AdSense/account readiness.

### H5. All six workflows

- **ci.yml:** verify Node 22 / Python 3.11 registrations, each referenced path and command order. Preserve original test assertions. Exercise offline safe commands in isolation; live Sheets/browser/dependency setup or master live/report paths are Blocked unless separately authorized and available.
- **pages.yml:** verify Python 3.12 publisher `--check`, `--out _site`, CNAME/.nojekyll/private exclusions, upload-pages-artifact path and deployment job dependencies. In isolated copies, publisher check/artifact generation can be compared after approval. Upload/deploy and owner Pages settings are Not executed. Python 3.12 unavailable → Blocked, not inferred equivalent to 3.11.
- **course-health.yml:** inspect gate and health command flags and issue behavior; do not create/update issues or execute owner-service actions.
- **live-guard.yml:** inspect schedule/manual registrations and weekly/live gate commands; remote probes and gh run lookups are Not executed. Local fallback logic is not a live-PASS substitute.
- **playwright.yml:** verify config/test paths, server binding and browser/dependency requirements; run existing tests only with an available offline browser environment in an isolated copy. No installs or production navigation.
- **sheet-sync.yml:** validate source paths/order, feeds/tutor bake, strip → indexes → editorial → reapply → inventories and final commit/push boundaries statically; live sync/commit/push is Not executed. Any offline fixture test must use the existing documented mode and retain original behavior, not alter the workflow.

YAML syntax/path checks are not workflow execution. Use a locally available validator if present; if missing, report Blocked rather than install or invent a syntax PASS. All original workflow sources are included in the ledger for review.

### H6. All existing compatibility launchers and unchanged tests

Enumerate and hash all 22 launchers and their canonical targets, verify exact import/require/subprocess targets and file existence. In isolated copies, compare canonical-vs-legacy invocations with forwarded argv and exit/failure propagation; use only offline-safe existing suites. A live-dependent launcher is Blocked, never automatically PASS. Retain test names, all assertions and intended rules. Preserve all original 43 SEO tests and 21 added correction cases (64 total), adapters, acceptance/report/CLI behavior; run that unit suite unchanged in isolation where its Python version is available. No production/external/browser QA has been performed here.

### H7. Checksums, sitemap, service worker and artifact

For each isolated copy, form the public set using the **unchanged actual publisher**, then compare sorted file inventory and SHA-256 for every public file, including HTML, JS/CSS, images, data, robots, ads.txt, CNAME, .nojekyll, sitemap XML, manifest and sw.js. Require exact path/byte equality between equivalent baseline and candidate runs, including voice.js. Separately compare current starting public files to the intended post-migration artifact so a baseline rebuild's pre-existing drift cannot be mislabeled as a move-induced change or silently committed.

Run publisher self-check in isolation, validate all sitemap URLs and service-worker precache targets still resolve to copied files, and verify no tools/pipeline source is copied. Compare indexing baseline, canonical/indexability state, sitemap URL sets, service-worker version/shell and public reference graph; no allowed-difference list for public bytes is introduced. Private reports may contain timestamps: compare structural fields as evidence with timestamps separately disclosed, never normalize public output or change gate acceptance. Any real FAIL stays FAIL; report-only exit 0 does not override a failed gate.

## I. Rollback plan

Rollback is per move and only in the isolated candidate until validation succeeds. Preserve pre-move current-worktree copies and hashes of the two original files. If either move fails equivalence, restore that exact pre-move file at its old path, remove only its newly introduced canonical implementation and adapter/registry/test additions belonging to this tranche, and verify the other move independently. If both fail, recommend KEEP for both; no alternate speculative layout is automatically authorized.

Before touching any file during an approved implementation, compare it to the captured pre-move hash; stop rather than overwrite concurrent user work. Never use git reset, checkout/restore from HEAD, stash, clean or a repository-wide revert: those would destroy earlier restructuring/SEO work. Do not overwrite generated public outputs during promotion; baseline/candidate generated files stay in isolated copies. If the working tree changes only in the expressly approved implementation/registry/test files, reverse that bounded patch against its captured pre-image. Recheck current-tree hashes, status, public inventory and all completed cleanup/SEO protections. No deploy is part of rollback; if an owner later deploys separately, rollback deployment requires separate approval.

## J. Deferred files and unresolved questions

The appendix enumerates **every DEFER path** with its evidence. Each stays at the current location. Deferral is a final audit disposition for this tranche, not a claim of dead code or a promise to move it later.

Outstanding work for any later expansion includes complete transitive write/service ownership for historical report/repair tools; computed sibling/import behavior in content generators; source-bank ownership and tools.lib cycles; live diagnostic/browser environments; campaign fonts/media/renderers and absolute /tmp paths; external/manual callers not visible in the repository; and a separately reviewed permission model for live integrations and workflows. None blocks the two local-only move recommendations, but all block a blanket generator/library migration. Do not create root build/ or change publisher deny rules without separate publication review and explicit approval.

### Exact future implementation/support-file allowlist

These **eight paths only** would change or be added after explicit approval:

| Path | Future change |
|---|---|
| tools/bundle-experience-css.py | Replace implementation body with the preserving legacy adapter |
| tools/build-dark-fix.py | Replace implementation body with the preserving legacy adapter |
| tools/pipeline/assets/bundle-experience-css.py | Add moved implementation; root expression only adjusted |
| tools/pipeline/assets/build-dark-fix.py | Add moved implementation; root expression only adjusted |
| tests/unit/test-build-system-compatibility.py | Add stdlib-only CLI/import/API/CWD/fixture checks; use temporary isolated copies, never working CSS |
| docs/architecture/build-system-path-map.json | Add separate two-move/adapter/API registry; retain completed cleanup manifest unchanged |
| docs/architecture/build-system-organization.md | Add this phase's decision, constraints, commands, validation outcomes and rollback record |
| .github/workflows/ci.yml | Add only `python3 -B tests/unit/test-build-system-compatibility.py` before the existing master-build step |

The new CI suite must not install dependencies, invoke live services or mutate the checkout. It should copy the minimal required scripts and input fixtures into a temporary repository-shaped tree and execute there. Initial pre-move-vs-post-move byte equivalence remains separate captured validation evidence; ongoing CI compares legacy/canonical contracts and baseline-defined fixtures without shipping a duplicate implementation. If compatibility cannot be demonstrated, the proposed implementation move stays KEEP and its support changes must not be promoted as a successful migration.

No extra owner decision is needed to interpret KEEP/DEFER: both mean no move in this tranche. The requested approval is specifically the two moves plus compatibility adapters, their phase-specific registration/documentation and additive validation tests/CI registration in the eight-path allowlist, with all original commands/public behavior retained. Broader folder consolidation remains unapproved.

## Validation result legend

- **PASS / FAIL:** only an actually executed, applicable check or assertion, with evidence.
- **Not executed:** deliberately not run in this read-only audit.
- **Blocked:** execution needs unavailable dependencies/runtime, service access or separate authorization.

Current application/build/workflow validation: **Not executed**. Static ledger coverage and repository-integrity verification are reported separately and do not imply application gate PASS.


## Complete candidate tree (unlisted repository paths unchanged)

```text
├── .github/
│   └── workflows/
│       ├── ci.yml [KEEP]
│       ├── course-health.yml [KEEP]
│       ├── live-guard.yml [KEEP]
│       ├── pages.yml [KEEP]
│       ├── playwright.yml [KEEP]
│       └── sheet-sync.yml [KEEP]
├── docs/
│   └── marketing/
│       ├── ekguru-brand-ad/
│       │   └── scripts/
│       │       ├── assemble_veo_master.py [DEFER]
│       │       ├── compose_music_and_mix.py [DEFER]
│       │       ├── render_9x16_reel_shorts.py [DEFER]
│       │       ├── render_brand_graphics.mjs [DEFER]
│       │       └── render_scene7_and_previz.py [DEFER]
│       ├── ekguru-social-campaign/
│       │   └── scripts/
│       │       ├── build_all_in_one_post.py [DEFER]
│       │       ├── prepare_framed_canvases.py [DEFER]
│       │       ├── render_all_in_one_post.mjs [DEFER]
│       │       ├── render_campaign_assets.mjs [DEFER]
│       │       └── shape_hindi_typography.py [DEFER]
│       └── growth-distribution-2026-11/
│           └── scripts/
│               ├── build_distribution_kit.js [DEFER]
│               ├── build_remaining_packs.js [DEFER]
│               ├── build_shorts_and_printables.py [DEFER]
│               └── build_visual_assets.py [DEFER]
├── package.json [KEEP]
├── playwright.config.mjs [KEEP]
├── sw.js [KEEP]
└── tools/
    ├── APPS-SCRIPT-SETUP.md [KEEP]
    ├── COPYRIGHT-DETECTION.md [KEEP]
    ├── _countries-cache.json [KEEP]
    ├── adminstats.js [KEEP]
    ├── adsready.js [KEEP]
    ├── apply-country-seo.py [KEEP]
    ├── apply-country-specifics.py [KEEP]
    ├── apply-country-tutor-availability.js [KEEP]
    ├── apply-tutor-location-specifics.py [KEEP]
    ├── apply-ultra.py [KEEP]
    ├── apps-script-mailer.gs [KEEP]
    ├── apps-script-questions.gs [KEEP]
    ├── arabic-phase3-content/
    │   ├── beginner.html [KEEP]
    │   ├── common-words.html [KEEP]
    │   ├── grammar.html [KEEP]
    │   ├── mistakes.html [KEEP]
    │   ├── numbers.html [KEEP]
    │   ├── pronunciation.html [KEEP]
    │   ├── reading.html [KEEP]
    │   ├── speaking-alone.html [KEEP]
    │   ├── travel.html [KEEP]
    │   └── vs-hindi.html [KEEP]
    ├── assets/
    │   └── og-fonts/
    │       ├── DejaVuSans-Bold.ttf [KEEP]
    │       ├── DejaVuSans.ttf [KEEP]
    │       └── LICENSE-DejaVu.txt [KEEP]
    ├── audit-adsense-readiness.py [KEEP]
    ├── audit-countries.py [DEFER]
    ├── audit-country-language-quality.py [DEFER]
    ├── audit-course-pronunciation.py [KEEP]
    ├── audit-course-quality.py [DEFER]
    ├── audit-dark-contrast.mjs [DEFER]
    ├── audit-features.py [DEFER]
    ├── audit-generator-safety.py [DEFER]
    ├── audit-hindi-content.py [DEFER]
    ├── audit-indian-topic-parity.py [KEEP]
    ├── audit-local-http.py [DEFER]
    ├── audit-perf-a11y.py [DEFER]
    ├── audit-phase1-gap.py [KEEP]
    ├── audit-phase5-static.py [DEFER]
    ├── audit-runtime-errors.py [DEFER]
    ├── audit-site-pages.js [DEFER]
    ├── audit-srs.py [DEFER]
    ├── audit-voice.py [DEFER]
    ├── author-depth.py [DEFER]
    ├── author-hindi-advanced.py [DEFER]
    ├── author-hindi-extension.py [DEFER]
    ├── author-hindi-halfsteps.py [DEFER]
    ├── author-hindi-lessons.py [DEFER]
    ├── author-hindi-levels.py [DEFER]
    ├── build-all.py [KEEP]
    ├── build-combined-code.mjs [KEEP]
    ├── build-contextual-entry-links.py [KEEP]
    ├── build-copy-index.js [KEEP]
    ├── build-country-funnel-pages.py [DEFER]
    ├── build-country-language-pages.py [KEEP]
    ├── build-country-languages.py [DEFER]
    ├── build-country-phrases.py [KEEP]
    ├── build-country-visuals.py [KEEP]
    ├── build-course-countries.py [KEEP]
    ├── build-course-hub.py [KEEP]
    ├── build-course-levels.py [KEEP]
    ├── build-courses.py [DEFER]
    ├── build-dark-fix.py [retained adapter after move]
    ├── build-ekguru-final-reports.py [DEFER]
    ├── build-faq.py [DEFER]
    ├── build-flashcards.py [KEEP]
    ├── build-full-page-inventory.py [KEEP]
    ├── build-global-pages.py [DEFER]
    ├── build-guide-hreflang.py [KEEP]
    ├── build-hindi-advanced.py [DEFER]
    ├── build-hindi-audio.py [DEFER]
    ├── build-hindi-classes-page.py [DEFER]
    ├── build-hindi-foundation-depth.py [KEEP]
    ├── build-hindi-foundation.py [DEFER]
    ├── build-hindi-hub.py [KEEP]
    ├── build-hindi-learning-library.py [KEEP]
    ├── build-hindi-nav.py [DEFER]
    ├── build-hindi-pages.py [KEEP]
    ├── build-hindi-phase3-posts.py [DEFER]
    ├── build-hindi-phrase-discovery.py [KEEP]
    ├── build-hindi-quizzes.py [KEEP]
    ├── build-hindi-structure.py [KEEP]
    ├── build-hindi-tutor-near-me-page.py [DEFER]
    ├── build-home-markets.py [DEFER]
    ├── build-home-tutors.js [KEEP]
    ├── build-inventory.py [KEEP]
    ├── build-join-schema.mjs [KEEP]
    ├── build-lang-packs.py [DEFER]
    ├── build-lang-topics.py [KEEP]
    ├── build-language-course-matrix.py [DEFER]
    ├── build-language-course.py [KEEP]
    ├── build-language-registry.py [KEEP]
    ├── build-learn-index.py [KEEP]
    ├── build-learn.py [DEFER]
    ├── build-learning-data.py [KEEP]
    ├── build-legacy-pages.py [KEEP]
    ├── build-legal-pages.py [KEEP]
    ├── build-market-pages.js [KEEP]
    ├── build-materials.py [KEEP]
    ├── build-name-pages-nonindic.py [DEFER]
    ├── build-names-js.py [DEFER]
    ├── build-numbers-pages.py [DEFER]
    ├── build-og-images.py [KEEP]
    ├── build-page-layer.py [KEEP]
    ├── build-phase2-content-inventory.py [KEEP]
    ├── build-phase3-originality-audit.py [KEEP]
    ├── build-phase7-pages.py [KEEP]
    ├── build-phase7-registries.py [KEEP]
    ├── build-phase7b-graph.py [DEFER]
    ├── build-phase7c-content-graph.py [DEFER]
    ├── build-phase7c-registries.py [KEEP]
    ├── build-print-sheets.py [KEEP]
    ├── build-public-dist.py [KEEP]
    ├── build-roster-rows.js [KEEP]
    ├── build-runtime.mjs [KEEP]
    ├── build-say-pages.py [DEFER]
    ├── build-search-index.py [KEEP]
    ├── build-seo-aeo-geo.py [KEEP]
    ├── build-shell.js [KEEP]
    ├── build-sitemaps.py [KEEP]
    ├── build-themes.py [KEEP]
    ├── build-time-pages-bodies.py [DEFER]
    ├── build-time-pages.py [KEEP]
    ├── build-toolbox-visuals.py [KEEP]
    ├── build-topic-map.py [DEFER]
    ├── build-tutor-pages.js [KEEP]
    ├── build-tutor-photo-variants.py [DEFER]
    ├── build-ultra-pages.py [KEEP]
    ├── build-visuals.py [KEEP]
    ├── build-voice-languages.py [KEEP]
    ├── build-world-art.py [KEEP]
    ├── build-world-course.py [KEEP]
    ├── build-world-phase3.py [KEEP]
    ├── bundle-experience-css.py [retained adapter after move]
    ├── check-advertising-launch.mjs [KEEP]
    ├── check-header-pages.mjs [DEFER]
    ├── check-header-pages.py [DEFER]
    ├── check-search-index.py [KEEP]
    ├── consolidate-header-css.py [DEFER]
    ├── contentguard.js [DEFER]
    ├── course-data/
    │   ├── ar.py [KEEP]
    │   ├── de.py [KEEP]
    │   ├── es.py [KEEP]
    │   ├── fr.py [KEEP]
    │   ├── it.py [KEEP]
    │   ├── ja.py [KEEP]
    │   ├── ko.py [KEEP]
    │   ├── pt.py [KEEP]
    │   ├── ru.py [KEEP]
    │   └── zh.py [KEEP]
    ├── course-health.py [KEEP]
    ├── dedupe-script-tags.py [KEEP]
    ├── depth-content/
    │   ├── ar.py [KEEP]
    │   ├── bn.py [KEEP]
    │   ├── de.py [KEEP]
    │   ├── es.py [KEEP]
    │   ├── fr.py [KEEP]
    │   ├── gu.py [KEEP]
    │   ├── it.py [KEEP]
    │   ├── ja.py [KEEP]
    │   ├── ko.py [KEEP]
    │   ├── mr.py [KEEP]
    │   ├── pa.py [KEEP]
    │   ├── pt.py [KEEP]
    │   ├── ru.py [KEEP]
    │   ├── ta.py [KEEP]
    │   ├── te.py [KEEP]
    │   ├── ur.py [KEEP]
    │   └── zh.py [KEEP]
    ├── depth_kit.py [KEEP]
    ├── diag-header.py [DEFER]
    ├── discovery_integrity.py [KEEP]
    ├── doctor.js [KEEP]
    ├── dr-drill.py [DEFER]
    ├── enrich-tool-inventory.py [DEFER]
    ├── fix-country-clusters.py [DEFER]
    ├── fix-course-brackets.py [DEFER]
    ├── fix-seo-issues.py [DEFER]
    ├── freeze-baseline.py [DEFER]
    ├── gate.js [KEEP]
    ├── generate-extended-courses.py [DEFER]
    ├── german-phase3-content/
    │   ├── beginner.html [KEEP]
    │   ├── common-words.html [KEEP]
    │   ├── grammar.html [KEEP]
    │   ├── mistakes.html [KEEP]
    │   ├── numbers.html [KEEP]
    │   ├── pronunciation.html [KEEP]
    │   ├── reading.html [KEEP]
    │   ├── speaking-alone.html [KEEP]
    │   ├── travel.html [KEEP]
    │   └── vs-hindi.html [KEEP]
    ├── header-nav-cleanup.py [DEFER]
    ├── hi-b3-source/
    │   ├── hi-b3-level.json [KEEP]
    │   ├── hi-b3-unit1.json [KEEP]
    │   ├── hi-b3-unit2.json [KEEP]
    │   └── hi-b3-unit3.json [KEEP]
    ├── hindi-ext-content/
    │   ├── c3.py [KEEP]
    │   ├── c4.py [KEEP]
    │   └── c5.py [KEEP]
    ├── hindi-foundation-content.py [KEEP]
    ├── hindi-halfsteps-content.py [KEEP]
    ├── hindi-phase3-content.txt [KEEP]
    ├── idle-live-final.py [DEFER]
    ├── indian-english.py [DEFER]
    ├── inject-ads.py [KEEP]
    ├── inject-advanced-seo.py [DEFER]
    ├── inject-consent.py [KEEP]
    ├── inject-flashcards.py [KEEP]
    ├── inject-modern.py [DEFER]
    ├── inject-questions-api.py [KEEP]
    ├── inject-recovery.py [DEFER]
    ├── inject-storybook.py [KEEP]
    ├── lang-data/
    │   ├── bengali.json [KEEP]
    │   ├── gujarati.json [KEEP]
    │   ├── kannada.json [KEEP]
    │   ├── malayalam.json [KEEP]
    │   ├── marathi.json [KEEP]
    │   ├── modules/
    │   │   ├── bn-education.json [KEEP]
    │   │   ├── bn-festivals.json [KEEP]
    │   │   ├── bn-health.json [KEEP]
    │   │   ├── bn-home.json [KEEP]
    │   │   ├── bn-office.json [KEEP]
    │   │   ├── bn-weather.json [KEEP]
    │   │   ├── gj-education.json [KEEP]
    │   │   ├── gj-festivals.json [KEEP]
    │   │   ├── gj-health.json [KEEP]
    │   │   ├── gj-home.json [KEEP]
    │   │   ├── gj-office.json [KEEP]
    │   │   ├── gj-weather.json [KEEP]
    │   │   ├── hi-education.json [KEEP]
    │   │   ├── hi-festivals.json [KEEP]
    │   │   ├── hi-health.json [KEEP]
    │   │   ├── hi-home.json [KEEP]
    │   │   ├── hi-office.json [KEEP]
    │   │   ├── hi-weather.json [KEEP]
    │   │   ├── kn-education.json [KEEP]
    │   │   ├── kn-festivals.json [KEEP]
    │   │   ├── kn-health.json [KEEP]
    │   │   ├── kn-home.json [KEEP]
    │   │   ├── kn-office.json [KEEP]
    │   │   ├── kn-weather.json [KEEP]
    │   │   ├── ml-education.json [KEEP]
    │   │   ├── ml-festivals.json [KEEP]
    │   │   ├── ml-health.json [KEEP]
    │   │   ├── ml-home.json [KEEP]
    │   │   ├── ml-office.json [KEEP]
    │   │   ├── ml-weather.json [KEEP]
    │   │   ├── mr-education.json [KEEP]
    │   │   ├── mr-festivals.json [KEEP]
    │   │   ├── mr-health.json [KEEP]
    │   │   ├── mr-home.json [KEEP]
    │   │   ├── mr-office.json [KEEP]
    │   │   ├── mr-weather.json [KEEP]
    │   │   ├── pj-education.json [KEEP]
    │   │   ├── pj-festivals.json [KEEP]
    │   │   ├── pj-health.json [KEEP]
    │   │   ├── pj-home.json [KEEP]
    │   │   ├── pj-office.json [KEEP]
    │   │   ├── pj-weather.json [KEEP]
    │   │   ├── ta-education.json [KEEP]
    │   │   ├── ta-festivals.json [KEEP]
    │   │   ├── ta-health.json [KEEP]
    │   │   ├── ta-home.json [KEEP]
    │   │   ├── ta-office.json [KEEP]
    │   │   ├── ta-weather.json [KEEP]
    │   │   ├── te-education.json [KEEP]
    │   │   ├── te-festivals.json [KEEP]
    │   │   ├── te-health.json [KEEP]
    │   │   ├── te-home.json [KEEP]
    │   │   ├── te-office.json [KEEP]
    │   │   ├── te-weather.json [KEEP]
    │   │   ├── ur-education.json [KEEP]
    │   │   ├── ur-festivals.json [KEEP]
    │   │   ├── ur-health.json [KEEP]
    │   │   ├── ur-home.json [KEEP]
    │   │   ├── ur-office.json [KEEP]
    │   │   └── ur-weather.json [KEEP]
    │   ├── punjabi.json [KEEP]
    │   ├── tamil.json [KEEP]
    │   ├── telugu.json [KEEP]
    │   └── urdu.json [KEEP]
    ├── langpacks_194_af1.py [KEEP]
    ├── langpacks_194_af2.py [KEEP]
    ├── langpacks_194_af3.py [KEEP]
    ├── langpacks_194_as1.py [KEEP]
    ├── langpacks_194_as2.py [KEEP]
    ├── langpacks_194_eu1.py [KEEP]
    ├── langpacks_194_eu2.py [KEEP]
    ├── langpacks_194_eu3.py [KEEP]
    ├── langpacks_194_eu4.py [KEEP]
    ├── langpacks_194_oc1a.py [KEEP]
    ├── langpacks_194_oc1b.py [KEEP]
    ├── langpacks_194_oc2.py [KEEP]
    ├── langpacks_extra.py [KEEP]
    ├── langsync.js [KEEP]
    ├── language-gate.py [KEEP]
    ├── learn-tools-audit.py [DEFER]
    ├── lib/
    │   ├── __init__.py [KEEP]
    │   ├── appscript_health.py [KEEP]
    │   ├── bank_builder.py [KEEP]
    │   ├── country_quality.py [KEEP]
    │   ├── en_in.py [KEEP]
    │   ├── extended_banks.py [KEEP]
    │   ├── extended_banks_asia.py [KEEP]
    │   ├── extended_banks_batch2.py [KEEP]
    │   ├── extended_banks_batch3.py [KEEP]
    │   ├── extended_banks_batch4.py [KEEP]
    │   ├── extended_banks_batch5.py [KEEP]
    │   ├── extended_banks_batch6.py [KEEP]
    │   ├── extended_banks_core.py [KEEP]
    │   ├── extended_banks_rest.py [KEEP]
    │   ├── extended_banks_world.py [KEEP]
    │   ├── flashcard_section.py [KEEP]
    │   ├── hindi_learner_offer.py [KEEP]
    │   ├── placeholders.py [KEEP]
    │   ├── site-data.js [KEEP]
    │   ├── speech_tags.py [KEEP]
    │   ├── text.py [KEEP]
    │   ├── ultra_content.py [KEEP]
    │   ├── validate-language-schema.mjs [KEEP]
    │   └── zero-state.js [KEEP]
    ├── live-browser-matrix.py [DEFER]
    ├── live-crawl.js [DEFER]
    ├── live-monitor.js [DEFER]
    ├── live-perf.py [DEFER]
    ├── live-route-check.py [DEFER]
    ├── live-seo-gate.py [KEEP]
    ├── localise-speaker-labels.py [DEFER]
    ├── make-copyright-page.py [DEFER]
    ├── make-email-reports.py [DEFER]
    ├── make-email-ultra-reports.py [DEFER]
    ├── make-master-audit-fast.py [DEFER]
    ├── make-master-audit.py [DEFER]
    ├── make-p0-reports.py [DEFER]
    ├── make-phase2-reports.py [DEFER]
    ├── make-phase3-baseline.py [DEFER]
    ├── make-phase3-final.py [DEFER]
    ├── make-phase3-reports.py [DEFER]
    ├── make-phase4-reports.py [DEFER]
    ├── make-phase5-reports.py [DEFER]
    ├── make-requirements.py [DEFER]
    ├── make-requirements2.py [DEFER]
    ├── make-sweep-reports.py [DEFER]
    ├── make-tutor-row.py [KEEP]
    ├── materials_b.py [KEEP]
    ├── materials_c.py [KEEP]
    ├── measure-header.py [DEFER]
    ├── merge-email-requirements.py [DEFER]
    ├── merge-remaining-requirements.py [DEFER]
    ├── normalise-romanisation.py [KEEP]
    ├── normalize-lang-data-classifiers.py [DEFER]
    ├── patch-header-css.py [DEFER]
    ├── patch-language-voice-controls.py [KEEP]
    ├── phase2-baseline.py [DEFER]
    ├── phase3-dynamic-tests.py [DEFER]
    ├── phase3-security-scan.py [DEFER]
    ├── phase4-browser-gate.py [DEFER]
    ├── pipeline/
    │   └── assets/
    │       ├── build-dark-fix.py [new canonical implementation]
    │       └── bundle-experience-css.py [new canonical implementation]
    ├── privacy.js [KEEP]
    ├── probe-providers.py [KEEP]
    ├── qa-perf-a11y.py [DEFER]
    ├── quarantine-country-funnels.py [KEEP]
    ├── quarantine-language-surfaces.py [KEEP]
    ├── quarantine-tutor-drafts.py [KEEP]
    ├── release-decision.js [DEFER]
    ├── render-og-images.mjs [DEFER]
    ├── render-report.js [DEFER]
    ├── repair-extended-levels.py [DEFER]
    ├── repair-phase1-advanced-glosses.py [KEEP]
    ├── run-phase7c-pipeline.py [KEEP]
    ├── security-audit.js [DEFER]
    ├── seocheck.js [KEEP]
    ├── sheet-fetch.js [KEEP]
    ├── sheetsync.js [KEEP]
    ├── spanish-phase3-content/
    │   ├── beginner.html [KEEP]
    │   ├── common-words.html [KEEP]
    │   ├── grammar.html [KEEP]
    │   ├── mistakes.html [KEEP]
    │   ├── numbers.html [KEEP]
    │   ├── pronunciation.html [KEEP]
    │   ├── reading.html [KEEP]
    │   ├── speaking-alone.html [KEEP]
    │   ├── travel.html [KEEP]
    │   └── vs-hindi.html [KEEP]
    ├── sweep-header-geometry.py [DEFER]
    ├── templates/
    │   └── country-funnel-base.tmpl [KEEP]
    ├── test-ad-policy.mjs [COMPATIBILITY LAUNCHER]
    ├── test-adaptive-practice.js [COMPATIBILITY LAUNCHER]
    ├── test-affiliate-disclosure.mjs [COMPATIBILITY LAUNCHER]
    ├── test-application-backend.mjs [COMPATIBILITY LAUNCHER]
    ├── test-copy-index.mjs [COMPATIBILITY LAUNCHER]
    ├── test-course-levels.mjs [COMPATIBILITY LAUNCHER]
    ├── test-email-security.js [COMPATIBILITY LAUNCHER]
    ├── test-email-system.js [COMPATIBILITY LAUNCHER]
    ├── test-join-css-visibility.mjs [COMPATIBILITY LAUNCHER]
    ├── test-join-wizard-nav.mjs [COMPATIBILITY LAUNCHER]
    ├── test-join-wizard.mjs [COMPATIBILITY LAUNCHER]
    ├── test-live-feed.js [COMPATIBILITY LAUNCHER]
    ├── test-question-api.mjs [COMPATIBILITY LAUNCHER]
    ├── test-reviews-fallback.js [COMPATIBILITY LAUNCHER]
    ├── test-routing.js [COMPATIBILITY LAUNCHER]
    ├── test-sheet-fetch.mjs [COMPATIBILITY LAUNCHER]
    ├── test-sheet-only-bake.mjs [COMPATIBILITY LAUNCHER]
    ├── test-support-static.mjs [COMPATIBILITY LAUNCHER]
    ├── test-theme-contrast.mjs [COMPATIBILITY LAUNCHER]
    ├── test-tools-functional.py [COMPATIBILITY LAUNCHER]
    ├── test-tutor-activation.mjs [COMPATIBILITY LAUNCHER]
    ├── test-usability-home.mjs [COMPATIBILITY LAUNCHER]
    ├── topic-meta.json [KEEP]
    ├── trend-analysis.py [KEEP]
    ├── ultra/
    │   └── contract.py [KEEP]
    ├── unfreeze-country-languages.py [DEFER]
    ├── update-editorial-metadata.py [KEEP]
    ├── validate-inventory.py [KEEP]
    ├── validate-sheets.py [DEFER]
    ├── verify-hindi-search.py [DEFER]
    ├── verify-hindi-typing.py [DEFER]
    ├── weekly-guard.sh [KEEP]
    ├── wire-token.py [KEEP]
    ├── write-final-gate.py [DEFER]
    ├── write-phase6-reports.py [DEFER]
    ├── write-phase7-reports.py [DEFER]
    ├── write-phase7b-final.py [DEFER]
    ├── write-phase7c-reports.py [DEFER]
    ├── write-phase7c-reports2.py [DEFER]
    └── write-zero-hero-evidence.py [DEFER]
```

## Complete exact path map — all 448 classified files

| # | Current path | Proposed path | Decision | Risk | Responsibility | Reason |
|---|---|---|---|---|---|---|
| 1 | tools/APPS-SCRIPT-SETUP.md | tools/APPS-SCRIPT-SETUP.md | KEEP | MEDIUM | Mailer Apps Script setup/deployment documentation. | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| 2 | tools/COPYRIGHT-DETECTION.md | tools/COPYRIGHT-DETECTION.md | KEEP | MEDIUM | Copy-index/copyright tooling documentation. | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| 3 | tools/_countries-cache.json | tools/_countries-cache.json | KEEP | MEDIUM | Country source/cache consumed by legacy page generation; static source, not executable tooling. | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| 4 | tools/adminstats.js | tools/adminstats.js | KEEP | HIGH | EkGuru — regenerates js/admin-stats.js from the live reports. Reads the previous file (for the deeply-generated static datasets: countries, languages, pairs, tutors, sitemapUrls) and re-computes the health blocks (seo / privacy / gate) plus page counts from the current tree + rep | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| 5 | tools/adsready.js | tools/adsready.js | KEEP | HIGH | EkGuru — AdSense readiness. Checks the concrete, verifiable preconditions for AdSense review against the LIVE site and the local tree. It reports facts only — it never claims approval or guaranteed revenue. Output: reports/adsready.json + a printed checklist. Run: node tools/adsr | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 6 | tools/apply-country-seo.py | tools/apply-country-seo.py | KEEP | HIGH | SEO copy and roster honesty for the learn-hindi-from-* country pages. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 7 | tools/apply-country-specifics.py | tools/apply-country-specifics.py | KEEP | HIGH | De-template the indexable learn-hindi-from-* pages (AdSense plan P3 / D-20). | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 8 | tools/apply-country-tutor-availability.js | tools/apply-country-tutor-availability.js | KEEP | HIGH | Keep the 196 country-learning pages honest when the public tutor roster is * empty. These pages were written when the site advertised a $6 tutor offer, * live lesson windows and available tutors. The current public roster is the * sheet-approved registry intersection, not every t | Protected tutor/booking/feed behavior or public-roster output ownership. Preserve integration and generation contracts; no move proposed. |
| 9 | tools/apply-tutor-location-specifics.py | tools/apply-tutor-location-specifics.py | KEEP | HIGH | De-template the /hindi-tutor/<place>/ pages (AdSense plan P3 / D-20). | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 10 | tools/apply-ultra.py | tools/apply-ultra.py | KEEP | HIGH | Additive, idempotent and strip-invertible site features. Everything it adds sits between | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 11 | tools/apps-script-mailer.gs | tools/apps-script-mailer.gs | KEEP | HIGH | Deployed Apps Script email relay; remote mail/authentication integration, not a website generator. | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 12 | tools/apps-script-questions.gs | tools/apps-script-questions.gs | KEEP | HIGH | Deployed Apps Script shared question flags/likes backend; remote persistent state. | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 13 | tools/arabic-phase3-content/beginner.html | tools/arabic-phase3-content/beginner.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 14 | tools/arabic-phase3-content/common-words.html | tools/arabic-phase3-content/common-words.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 15 | tools/arabic-phase3-content/grammar.html | tools/arabic-phase3-content/grammar.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 16 | tools/arabic-phase3-content/mistakes.html | tools/arabic-phase3-content/mistakes.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 17 | tools/arabic-phase3-content/numbers.html | tools/arabic-phase3-content/numbers.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 18 | tools/arabic-phase3-content/pronunciation.html | tools/arabic-phase3-content/pronunciation.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 19 | tools/arabic-phase3-content/reading.html | tools/arabic-phase3-content/reading.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 20 | tools/arabic-phase3-content/speaking-alone.html | tools/arabic-phase3-content/speaking-alone.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 21 | tools/arabic-phase3-content/travel.html | tools/arabic-phase3-content/travel.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 22 | tools/arabic-phase3-content/vs-hindi.html | tools/arabic-phase3-content/vs-hindi.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 23 | tools/assets/og-fonts/DejaVuSans-Bold.ttf | tools/assets/og-fonts/DejaVuSans-Bold.ttf | KEEP | LOW | Bundled OG renderer font/license input. | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| 24 | tools/assets/og-fonts/DejaVuSans.ttf | tools/assets/og-fonts/DejaVuSans.ttf | KEEP | LOW | Bundled OG renderer font/license input. | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| 25 | tools/assets/og-fonts/LICENSE-DejaVu.txt | tools/assets/og-fonts/LICENSE-DejaVu.txt | KEEP | LOW | Bundled OG renderer font/license input. | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| 26 | tools/audit-adsense-readiness.py | tools/audit-adsense-readiness.py | KEEP | HIGH | Conservative global publishability/AdSense-readiness triage. | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| 27 | tools/audit-countries.py | tools/audit-countries.py | DEFER | HIGH | Phase 7B §19 — country-page de-templating audit. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 28 | tools/audit-country-language-quality.py | tools/audit-country-language-quality.py | DEFER | HIGH | Classify every country-language relation without upgrading weak evidence. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 29 | tools/audit-course-pronunciation.py | tools/audit-course-pronunciation.py | KEEP | HIGH | Audit source-verified IPA coverage in the published CEFR course data. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 30 | tools/audit-course-quality.py | tools/audit-course-quality.py | DEFER | HIGH | Audit course data for publication-breaking templated/filler content. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 31 | tools/audit-dark-contrast.mjs | tools/audit-dark-contrast.mjs | DEFER | HIGH | Dark-mode / light-mode text-contrast audit (WCAG 2.x ratios). * * Loads each page in headless Chromium with the EkGuru theme forced * (localStorage `ekguru:theme:v2` + html[data-theme]), scrolls once so lazy * sections mount, then walks EVERY text node and computes the contrast o | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 32 | tools/audit-features.py | tools/audit-features.py | DEFER | HIGH | Phase 7B §8 — FEATURE REALITY MATRIX (real Chromium). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 33 | tools/audit-generator-safety.py | tools/audit-generator-safety.py | DEFER | HIGH | Phase 7B §22 — generator-safety verification. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 34 | tools/audit-hindi-content.py | tools/audit-hindi-content.py | DEFER | HIGH | Phase 4 §1/§26/§27 — audit the entire Hindi content estate and produce | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 35 | tools/audit-indian-topic-parity.py | tools/audit-indian-topic-parity.py | KEEP | HIGH | Audit the rendered root-level topic trees for the nine Indian languages. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 36 | tools/audit-local-http.py | tools/audit-local-http.py | DEFER | HIGH | Exercise the built site through HTTP instead of inspecting files directly. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 37 | tools/audit-perf-a11y.py | tools/audit-perf-a11y.py | DEFER | HIGH | Phase 7B §24 (performance) + §25 (accessibility) spot-check. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 38 | tools/audit-phase1-gap.py | tools/audit-phase1-gap.py | KEEP | HIGH | PHASE 1 gap report — what every PUBLISHED language still needs. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 39 | tools/audit-phase5-static.py | tools/audit-phase5-static.py | DEFER | HIGH | Phase 5 §3/§9 — static interaction inventory + dead/hidden/unreachable UI sweep. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 40 | tools/audit-runtime-errors.py | tools/audit-runtime-errors.py | DEFER | HIGH | Phase 7B §7 — Console / runtime forensics across the whole site. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 41 | tools/audit-site-pages.js | tools/audit-site-pages.js | DEFER | HIGH | EkGuru — SITE-WIDE PAGE + TUTOR AUDIT (Nov 2026) Run: node tools/audit-site-pages.js [path...] Checks every HTML page for: 1. unbalanced HTML comments (visible comment-text leaks) 2. escaped comment markers (--&gt; / &lt;!--) in text 3. local <script src> that points at a missing | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 42 | tools/audit-srs.py | tools/audit-srs.py | DEFER | HIGH | Phase 7B §10 — SRS deep real test (real Chromium). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 43 | tools/audit-voice.py | tools/audit-voice.py | DEFER | HIGH | Phase 7B §9 — VOICE deep real test (real Chromium). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 44 | tools/author-depth.py | tools/author-depth.py | DEFER | HIGH | PHASE 1 depth author for a published language (the non-Hindi languages). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 45 | tools/author-hindi-advanced.py | tools/author-hindi-advanced.py | DEFER | HIGH | Hindi B3 ("Advanced") — authored level, merged into its course file. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 46 | tools/author-hindi-extension.py | tools/author-hindi-extension.py | DEFER | HIGH | Hindi C3 / C4 / C5 — the post-C2 extension ladder, authored and published. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 47 | tools/author-hindi-halfsteps.py | tools/author-hindi-halfsteps.py | DEFER | HIGH | Hindi PHASE 1 — the half-step rungs (A1+ A2+ B1+ B2+ C1+). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 48 | tools/author-hindi-lessons.py | tools/author-hindi-lessons.py | DEFER | HIGH | Hindi PHASE 1 depth — the third lesson in every A1 and A2 unit. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 49 | tools/author-hindi-levels.py | tools/author-hindi-levels.py | DEFER | HIGH | Hindi PHASE 1 depth — the `level.extra` block for each CEFR rung. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 50 | tools/build-all.py | tools/build-all.py | KEEP | HIGH | EkGuru — ONE-COMMAND FULL REBUILD (v130). | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 51 | tools/build-combined-code.mjs | tools/build-combined-code.mjs | KEEP | HIGH | EkGuru: build apps-script/combined/Code.gs Concatenates the three form-backend sources into ONE file for a single Apps Script project, in this order: 1. ApplicationSchema.gs -> SECTION 1 (schema) 2. ApplicationIntake.gs -> SECTION 2 (application backend) 3. Unified.gs -> SECTION  | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 52 | tools/build-contextual-entry-links.py | tools/build-contextual-entry-links.py | KEEP | HIGH | Add bounded contextual entry points for eight existing search landing pages. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 53 | tools/build-copy-index.js | tools/build-copy-index.js | KEEP | HIGH | EkGuru — COPY INDEX (ownership fingerprints) -------------------------------------------------------------------------- Prakash: "copyright only ekguru ke pass hi ye pata hona chahiye ki jo text apna hai vo apna hi ho ... admin mai agar koi sheet copy kar de to pata chal jaye ... | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| 54 | tools/build-country-funnel-pages.py | tools/build-country-funnel-pages.py | DEFER | HIGH | EkGuru — the 38 missing learn-hindi-from-* country pages (196 total). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 55 | tools/build-country-language-pages.py | tools/build-country-language-pages.py | KEEP | HIGH | EkGuru — country language-guide pages from the inventory (all 194). | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 56 | tools/build-country-languages.py | tools/build-country-languages.py | DEFER | HIGH | Build the quality-labelled country → language list for the homepage. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 57 | tools/build-country-phrases.py | tools/build-country-phrases.py | KEEP | HIGH | Owner-approved consolidation of 196 empty country daily-phrase URLs. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 58 | tools/build-country-visuals.py | tools/build-country-visuals.py | KEEP | HIGH | The country figures: one picture per country, on every page about it. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 59 | tools/build-course-countries.py | tools/build-course-countries.py | KEEP | HIGH | Write /courses/by-country/ — every country, and the languages we can teach for it. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 60 | tools/build-course-hub.py | tools/build-course-hub.py | KEEP | HIGH | Structured course setup — writes the static course hub and the home teaser. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 61 | tools/build-course-levels.py | tools/build-course-levels.py | KEEP | HIGH | Every authored course level as a readable page (CEFR A1–C2, plus extras). | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 62 | tools/build-courses.py | tools/build-courses.py | DEFER | HIGH | Course builder/validator — Phase program (10 languages per phase). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 63 | tools/build-dark-fix.py | tools/pipeline/assets/build-dark-fix.py | MOVE | MEDIUM | Derive dark/contrast theme overrides from the fixed SOURCES list and replace the EKGURU_DARK_FIX block. | Known executable callers are build-all CLI commands; full reviewed source uses stdlib only, no remote access, no sibling module imports. Retain old path with namespace-preserving compatibility adapter and validate both entrypoints before accepting migration. |
| 64 | tools/build-ekguru-final-reports.py | tools/build-ekguru-final-reports.py | DEFER | HIGH | Build the forensic reconciliation, page matrix and monetization report. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 65 | tools/build-faq.py | tools/build-faq.py | DEFER | HIGH | Generate /faq/ — genuine learner FAQs with contextual journey links. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 66 | tools/build-flashcards.py | tools/build-flashcards.py | KEEP | HIGH | Build per-language flashcard decks from the authored course vocabulary. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 67 | tools/build-full-page-inventory.py | tools/build-full-page-inventory.py | KEEP | HIGH | EkGuru — full public page inventory (master audit §2). | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| 68 | tools/build-global-pages.py | tools/build-global-pages.py | DEFER | HIGH | Phase 7C §32/§33 — generate the GLOBAL learning dashboard. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 69 | tools/build-guide-hreflang.py | tools/build-guide-hreflang.py | KEEP | HIGH | Keep the existing localized beginner-guide alternate set reciprocal. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 70 | tools/build-hindi-advanced.py | tools/build-hindi-advanced.py | DEFER | HIGH | EkGuru — Hindi Advanced level builder (additive; never touches the 15 lessons). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 71 | tools/build-hindi-audio.py | tools/build-hindi-audio.py | DEFER | HIGH | Phase 6 §4/§5/§7 — tag key vocabulary for Listen (computer voice) + Add to Review. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 72 | tools/build-hindi-classes-page.py | tools/build-hindi-classes-page.py | DEFER | HIGH | Build the `hindi-classes` hub page from the find-tutors.html shell. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 73 | tools/build-hindi-foundation-depth.py | tools/build-hindi-foundation-depth.py | KEEP | HIGH | Add authored depth to existing Foundation URLs. No indexability/URL/progress changes. | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| 74 | tools/build-hindi-foundation.py | tools/build-hindi-foundation.py | DEFER | HIGH | EkGuru — build the Hindi Foundation section (हिंदी की नींव). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 75 | tools/build-hindi-hub.py | tools/build-hindi-hub.py | KEEP | HIGH | EkGuru — THE ONE HINDI HUB  (17 Nov 2026, owner: "ek Hindi se hi khulna chahiye"; | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 76 | tools/build-hindi-learning-library.py | tools/build-hindi-learning-library.py | KEEP | HIGH | Build a deduplicated, source-linked Hindi learning collection on the existing practice hub. | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| 77 | tools/build-hindi-nav.py | tools/build-hindi-nav.py | DEFER | HIGH | EkGuru Phase 4 — wire the canonical Learn Hindi structure into existing pages. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 78 | tools/build-hindi-pages.py | tools/build-hindi-pages.py | KEEP | HIGH | Phase 6 §6–§17 — generate the Hindi learning-product pages + decorate lessons. | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| 79 | tools/build-hindi-phase3-posts.py | tools/build-hindi-phase3-posts.py | DEFER | HIGH | Assemble the two missing Hindi PHASE 3 posts from the committed guide scaffold. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 80 | tools/build-hindi-phrase-discovery.py | tools/build-hindi-phrase-discovery.py | KEEP | HIGH | Connect existing phrase answers to their existing hubs; never publish new URLs. | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| 81 | tools/build-hindi-quizzes.py | tools/build-hindi-quizzes.py | KEEP | HIGH | Phase 6 §3 — inject lesson quick quizzes from the canonical bank. | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| 82 | tools/build-hindi-structure.py | tools/build-hindi-structure.py | KEEP | HIGH | EkGuru Phase 4 — build the canonical Learn Hindi structure (hub + levels + topics). | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| 83 | tools/build-hindi-tutor-near-me-page.py | tools/build-hindi-tutor-near-me-page.py | DEFER | HIGH | Build the `hindi-tutor-near-me` hub page from the find-tutors.html shell. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 84 | tools/build-home-markets.py | tools/build-home-markets.py | DEFER | HIGH | Regenerate the static country grid in the home page's markets section. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 85 | tools/build-home-tutors.js | tools/build-home-tutors.js | KEEP | HIGH | EkGuru — HOME PAGE TUTOR CARDS -------------------------------------------------------------------------- Rewrites the static tutor list on the English home page from the live roster (js/tutors/*.js + the sheet overrides, through tools/lib/site-data.js) and keeps the tutor-profil | Protected tutor/booking/feed behavior or public-roster output ownership. Preserve integration and generation contracts; no move proposed. |
| 86 | tools/build-inventory.py | tools/build-inventory.py | KEEP | HIGH | EkGuru — language-inventory BUILD (owner Phases 2-5, 7-10, 12, 15, 17). | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 87 | tools/build-join-schema.mjs | tools/build-join-schema.mjs | KEEP | HIGH | EkGuru: build js/join-schema.js from apps-script/ApplicationSchema.gs --------------------------------------------------------- The wizard and the Apps Script backend must agree, exactly, on every field name and every character limit. Two hand-maintained lists drift — that is how | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 88 | tools/build-lang-packs.py | tools/build-lang-packs.py | DEFER | HIGH | Phase 7C Stage 3 — author the multi-language starter packs (BETA proof of | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 89 | tools/build-lang-topics.py | tools/build-lang-topics.py | KEEP | HIGH | EkGuru — LANGUAGE TOPIC BUILDER (Phase 2: all nine Indian languages). | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| 90 | tools/build-language-course-matrix.py | tools/build-language-course-matrix.py | DEFER | HIGH | EkGuru — language/course matrix (master audit §7). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 91 | tools/build-language-course.py | tools/build-language-course.py | KEEP | HIGH | Build a complete trilingual (EN + HI + target) language course under learn/<slug>/. | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| 92 | tools/build-language-registry.py | tools/build-language-registry.py | KEEP | HIGH | U4: 700-language DRAFT registry + 197 country contexts from the existing inventory. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 93 | tools/build-learn-index.py | tools/build-learn-index.py | KEEP | HIGH | EkGuru — /learn/: EVERY LANGUAGE FROM ONE PAGE  (18 Nov 2026). | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 94 | tools/build-learn.py | tools/build-learn.py | DEFER | HIGH | EkGuru — regenerate Learn Paths + Practice lab pages (v100). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 95 | tools/build-learning-data.py | tools/build-learning-data.py | KEEP | HIGH | Bounded on-device learning inputs from the CURRENTLY available levels. Never authorises a course. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 96 | tools/build-legacy-pages.py | tools/build-legacy-pages.py | KEEP | HIGH | EkGuru — THE READING LAYER (974 hand-written pages move onto the design system). | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| 97 | tools/build-legal-pages.py | tools/build-legal-pages.py | KEEP | HIGH | Redesign the five legal pages (terms, privacy, disclaimer, copyright, | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 98 | tools/build-market-pages.js | tools/build-market-pages.js | KEEP | HIGH | EkGuru — MARKET HOME PAGES -------------------------------------------------------------------------- Rebuilds the home page of the six translated markets so they are the same page as the English one, in their own language: es/index.html fr/index.html de/index.html pt/index.html  | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 99 | tools/build-materials.py | tools/build-materials.py | KEEP | HIGH | EkGuru — build the /materials/ learning-resource hub (Phase 2). | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| 100 | tools/build-name-pages-nonindic.py | tools/build-name-pages-nonindic.py | DEFER | HIGH | Generate name-in-<lang> pages for non-Indic scripts. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 101 | tools/build-names-js.py | tools/build-names-js.py | DEFER | HIGH | Generate js/names-data.js from data/names/names.json. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 102 | tools/build-numbers-pages.py | tools/build-numbers-pages.py | DEFER | HIGH | Build the numbers pages and their generated JS from data/numbers/*.json. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 103 | tools/build-og-images.py | tools/build-og-images.py | KEEP | HIGH | Generate language/level Open Graph cards from published course pages. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 104 | tools/build-page-layer.py | tools/build-page-layer.py | KEEP | HIGH | EkGuru — THE PAGE LAYER (the 483 lesson/answer/hub pages join §25). | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 105 | tools/build-phase2-content-inventory.py | tools/build-phase2-content-inventory.py | KEEP | HIGH | Build the repository-only Phase 2 content inventory. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 106 | tools/build-phase3-originality-audit.py | tools/build-phase3-originality-audit.py | KEEP | HIGH | Build the Phase 3 repository-backed originality review matrix. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 107 | tools/build-phase7-pages.py | tools/build-phase7-pages.py | KEEP | HIGH | Phase 7 — build the global language hub + goal-based onboarding page. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 108 | tools/build-phase7-registries.py | tools/build-phase7-registries.py | KEEP | HIGH | Phase 7 — build the canonical registries + content schema (single source of truth). | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 109 | tools/build-phase7b-graph.py | tools/build-phase7b-graph.py | DEFER | HIGH | Phase 7B §4 — static dependency graph + load-order forensics. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 110 | tools/build-phase7c-content-graph.py | tools/build-phase7c-content-graph.py | DEFER | HIGH | Phase 7C §9 — build the NORMALIZED GLOBAL CONTENT GRAPH from real content. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 111 | tools/build-phase7c-registries.py | tools/build-phase7c-registries.py | KEEP | HIGH | Phase 7C §6/§7 — extend the global registries with real per-language QA | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 112 | tools/build-print-sheets.py | tools/build-print-sheets.py | KEEP | HIGH | EkGuru — WHICH PAGES PRINT AS A SHEET (and what exactly prints). | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 113 | tools/build-public-dist.py | tools/build-public-dist.py | KEEP | HIGH | Protected website-only copier, sitemap/precache/private-reference self-check and Pages artifact boundary. | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 114 | tools/build-roster-rows.js | tools/build-roster-rows.js | KEEP | HIGH | EkGuru — ROSTER ROWS (the tutor lists baked into other pages) -------------------------------------------------------------------------- Three pre-rendered shapes list the tutors, outside the home page and the profiles, and every one of them was hand-maintained and stale: div.tut | Protected tutor/booking/feed behavior or public-roster output ownership. Preserve integration and generation contracts; no move proposed. |
| 115 | tools/build-runtime.mjs | tools/build-runtime.mjs | KEEP | HIGH | Terser runtime minification with source-hash header and byte budgets; writes js/voice.js when stale. | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 116 | tools/build-say-pages.py | tools/build-say-pages.py | DEFER | HIGH | Generate 'how to say X in Hindi' Q&A pages for high-volume search queries. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 117 | tools/build-search-index.py | tools/build-search-index.py | KEEP | HIGH | Build-time generator for search-index.json + the section filter pills in | Publication/discovery contract: exact public-set, sitemap/robots, search-index and shared parser dependencies. Retain paths and scan behavior; no publisher or indexation change. |
| 118 | tools/build-seo-aeo-geo.py | tools/build-seo-aeo-geo.py | KEEP | HIGH | EkGuru — SEO + AEO + GEO Discovery Generator & Gate (`tools/build-seo-aeo-geo.py`). | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 119 | tools/build-shell.js | tools/build-shell.js | KEEP | HIGH | EkGuru — THE SHELL: one header and one footer for every page -------------------------------------------------------------------------- 1,564 pages, and until this tool existed they carried two different site chromes and three different taglines: 27 pages the hand-written shell ( | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 120 | tools/build-sitemaps.py | tools/build-sitemaps.py | KEEP | HIGH | Prune sitemap URLs against the files that can actually be indexed. | Publication/discovery contract: exact public-set, sitemap/robots, search-index and shared parser dependencies. Retain paths and scan behavior; no publisher or indexation change. |
| 121 | tools/build-themes.py | tools/build-themes.py | KEEP | HIGH | Script-aware, AA-tested per-language tokens and abstract geometric patterns. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 122 | tools/build-time-pages-bodies.py | tools/build-time-pages-bodies.py | DEFER | HIGH | Build the four new time-page bodies (gu/kn/te/ur) from the Punjabi shell. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 123 | tools/build-time-pages.py | tools/build-time-pages.py | KEEP | HIGH | Build the time-and-days pages and their generated JS from data/time/*.json. | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| 124 | tools/build-toolbox-visuals.py | tools/build-toolbox-visuals.py | KEEP | HIGH | One plate per tool — the picture the toolbox never had. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 125 | tools/build-topic-map.py | tools/build-topic-map.py | DEFER | HIGH | EkGuru — CHAPTER THEME MAP (v147). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 126 | tools/build-tutor-pages.js | tools/build-tutor-pages.js | KEEP | HIGH | EkGuru — TUTOR PROFILE PAGES -------------------------------------------------------------------------- Rebuilds the pre-rendered profile of every tutor in the registry: tutor/sushila-g/index.html tutor/hemlata/index.html tutor/shikha-dutta/index.html tutor/tara/index.html tutor/ | Protected tutor/booking/feed behavior or public-roster output ownership. Preserve integration and generation contracts; no move proposed. |
| 127 | tools/build-tutor-photo-variants.py | tools/build-tutor-photo-variants.py | DEFER | HIGH | EkGuru — tutor card photo variants. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 128 | tools/build-ultra-pages.py | tools/build-ultra-pages.py | KEEP | HIGH | Honest trust/progress/design/review pages. All are noindex (owner rule: new pages stay noindex) and | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 129 | tools/build-visuals.py | tools/build-visuals.py | KEEP | HIGH | EkGuru — the level visuals: the same learner, from A1 to C2. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 130 | tools/build-voice-languages.py | tools/build-voice-languages.py | KEEP | HIGH | BCP-47 speech tags from the registry -> js/voice-languages.js, plus empty recording manifests. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 131 | tools/build-world-art.py | tools/build-world-art.py | KEEP | HIGH | Design the per-language world artwork — writes images/xp/world-*.svg. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 132 | tools/build-world-course.py | tools/build-world-course.py | KEEP | HIGH | Phase 7C Stage 7+ — full courses, one language at a time, popular first. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 133 | tools/build-world-phase3.py | tools/build-world-phase3.py | KEEP | HIGH | Build long-form Learn posts for world-course languages with authored packs. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 134 | tools/bundle-experience-css.py | tools/pipeline/assets/bundle-experience-css.py | MOVE | MEDIUM | Conservatively compact css/experience.css and replace its marker-delimited layer in css/style.min.css. | Known executable callers are build-all CLI commands; full reviewed source uses stdlib only, no remote access, no sibling module imports. Retain old path with namespace-preserving compatibility adapter and validate both entrypoints before accepting migration. |
| 135 | tools/check-advertising-launch.mjs | tools/check-advertising-launch.mjs | KEEP | HIGH | #!/usr/bin/env node // Read-only checklist. This cannot certify a CMP or authorize ad serving. import { readFileSync, existsSync } from 'node:fs'; const read = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8'); const mon = JSON.parse(read('data/monetization/google- | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 136 | tools/check-header-pages.mjs | tools/check-header-pages.mjs | DEFER | HIGH | Multi-page header geometry check — Node port of tools/check-header-pages.py. * * WHY THIS EXISTS * --------------- * tools/check-header-pages.py is the canonical gate, but it launches the * browser through Playwright. In environments where the Playwright browser * download is blo | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 137 | tools/check-header-pages.py | tools/check-header-pages.py | DEFER | HIGH | Multi-page header geometry check (complements sweep-header-geometry.py, | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 138 | tools/check-search-index.py | tools/check-search-index.py | KEEP | HIGH | Fail if local search exposes quarantined/noindex or stale pages. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 139 | tools/consolidate-header-css.py | tools/consolidate-header-css.py | DEFER | HIGH | Consolidate header CSS into one organized block (v102). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 140 | tools/contentguard.js | tools/contentguard.js | DEFER | HIGH | EkGuru — ContentGuard: originality inventory + fingerprinting + internal duplicate (self-copy) detection + copy-probe generation. Outputs: reports/content-ownership-inventory.json per-asset records reports/fingerprints.json hash / simhash / minhash store reports/selfcopy-report.j | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 141 | tools/course-data/ar.py | tools/course-data/ar.py | KEEP | HIGH | Authored Arabic course data. Language config + content. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 142 | tools/course-data/de.py | tools/course-data/de.py | KEEP | HIGH | Authored German course data. Language config + content. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 143 | tools/course-data/es.py | tools/course-data/es.py | KEEP | HIGH | Authored Spanish course data (Stage 7). Language config + content. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 144 | tools/course-data/fr.py | tools/course-data/fr.py | KEEP | HIGH | Authored French course data (Stage 8). Language config + content. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 145 | tools/course-data/it.py | tools/course-data/it.py | KEEP | HIGH | Authored Italian course data. Language config + content. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 146 | tools/course-data/ja.py | tools/course-data/ja.py | KEEP | HIGH | Authored Japanese course data. Language config + content. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 147 | tools/course-data/ko.py | tools/course-data/ko.py | KEEP | HIGH | Authored Korean course data. Language config + content. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 148 | tools/course-data/pt.py | tools/course-data/pt.py | KEEP | HIGH | Authored Portuguese course data. Language config + content. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 149 | tools/course-data/ru.py | tools/course-data/ru.py | KEEP | HIGH | Authored Russian course data. Language config + content. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 150 | tools/course-data/zh.py | tools/course-data/zh.py | KEEP | HIGH | Authored Chinese (Mandarin) course data. Language config + content. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 151 | tools/course-health.py | tools/course-health.py | KEEP | HIGH | Weekly course health: voice tags/manifests, unverified or stale sources, reviewer gaps and gate failures. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 152 | tools/dedupe-script-tags.py | tools/dedupe-script-tags.py | KEEP | HIGH | Remove repeated external script tags from public HTML pages. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 153 | tools/depth-content/ar.py | tools/depth-content/ar.py | KEEP | HIGH | Arabic PHASE 1 depth — extras, third lessons, half-step rungs. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 154 | tools/depth-content/bn.py | tools/depth-content/bn.py | KEEP | HIGH | Bengali PHASE 1 depth — extras, third lessons, half-step rungs. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 155 | tools/depth-content/de.py | tools/depth-content/de.py | KEEP | HIGH | German PHASE 1 depth — extras, third lessons, half-step rungs. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 156 | tools/depth-content/es.py | tools/depth-content/es.py | KEEP | HIGH | Spanish PHASE 1 depth — extras, third lessons, half-step rungs. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 157 | tools/depth-content/fr.py | tools/depth-content/fr.py | KEEP | HIGH | PHASE 1 depth for French (`fr`). | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 158 | tools/depth-content/gu.py | tools/depth-content/gu.py | KEEP | HIGH | Gujarati PHASE 1 depth — extras, third lessons, half-step rungs. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 159 | tools/depth-content/it.py | tools/depth-content/it.py | KEEP | HIGH | PHASE 1 depth for Italian (`it`). | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 160 | tools/depth-content/ja.py | tools/depth-content/ja.py | KEEP | HIGH | Japanese PHASE 1 depth — extras, third lessons, half-step rungs. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 161 | tools/depth-content/ko.py | tools/depth-content/ko.py | KEEP | HIGH | Korean PHASE 1 depth — extras, third lessons, half-step rungs. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 162 | tools/depth-content/mr.py | tools/depth-content/mr.py | KEEP | HIGH | Marathi PHASE 1 depth — extras, third lessons, half-step rungs. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 163 | tools/depth-content/pa.py | tools/depth-content/pa.py | KEEP | HIGH | Punjabi PHASE 1 depth — extras, third lessons, half-step rungs. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 164 | tools/depth-content/pt.py | tools/depth-content/pt.py | KEEP | HIGH | Portuguese (Brazil) PHASE 1 depth — extras, third lessons, half-step rungs. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 165 | tools/depth-content/ru.py | tools/depth-content/ru.py | KEEP | HIGH | Russian PHASE 1 depth — extras, third lessons, half-step rungs. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 166 | tools/depth-content/ta.py | tools/depth-content/ta.py | KEEP | HIGH | Tamil PHASE 1 depth — extras, third lessons, half-step rungs. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 167 | tools/depth-content/te.py | tools/depth-content/te.py | KEEP | HIGH | Telugu PHASE 1 depth — six CEFR extras, third lessons, and five half-steps. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 168 | tools/depth-content/ur.py | tools/depth-content/ur.py | KEEP | HIGH | Urdu Phase 1 depth: authored extras, third lessons and five half-steps. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 169 | tools/depth-content/zh.py | tools/depth-content/zh.py | KEEP | HIGH | Mandarin Phase 1 depth: six extras, third lessons and five half-steps. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 170 | tools/depth_kit.py | tools/depth_kit.py | KEEP | HIGH | Helpers for the per-language PHASE 1 depth modules (`tools/depth-content/`). | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 171 | tools/diag-header.py | tools/diag-header.py | DEFER | HIGH | Diagnose EkGuru header overflow: layout boxes vs painted text overflow. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 172 | tools/discovery_integrity.py | tools/discovery_integrity.py | KEEP | HIGH | Check real public-deploy links, assets and search language annotations. | Publication/discovery contract: exact public-set, sitemap/robots, search-index and shared parser dependencies. Retain paths and scan behavior; no publisher or indexation change. |
| 173 | tools/doctor.js | tools/doctor.js | KEEP | HIGH | EkGuru — DOCTOR. One command to run the whole health chain and leave the dashboard honest: node tools/doctor.js Runs, in order: 1. node tools/seocheck.js -> reports/seo.json 2. node tools/privacy.js --sheets --live --json -> reports/privacy-scan.json 3. node tools/gate.js -> repo | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| 174 | tools/dr-drill.py | tools/dr-drill.py | DEFER | HIGH | EkGuru — Disaster-recovery drills (safe, away from production). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 175 | tools/enrich-tool-inventory.py | tools/enrich-tool-inventory.py | DEFER | HIGH | Enrich reports/tool-inventory-phase2.json with the per-tool fields the | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 176 | tools/fix-country-clusters.py | tools/fix-country-clusters.py | DEFER | HIGH | Phase 7B §19 — de-template the WORST country-page similarity clusters. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 177 | tools/fix-course-brackets.py | tools/fix-course-brackets.py | DEFER | HIGH | Auto-fix lesson/unit/test boundary brackets in course JSON files. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 178 | tools/fix-seo-issues.py | tools/fix-seo-issues.py | DEFER | HIGH | Fix SEO metadata issues across all HTML pages: | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 179 | tools/freeze-baseline.py | tools/freeze-baseline.py | DEFER | HIGH | Freeze the release baseline (both the Final-Readiness and the ULTRA-360 | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 180 | tools/gate.js | tools/gate.js | KEEP | HIGH | EkGuru — the DOCTOR / build gate. One command that runs every health check the site must pass before a deploy is honest, and writes the verdict the admin dashboard displays. Output: reports/doctor.json { doctorProblems, doctorWarnings, doctorChecks, seoPass, privacyState, results | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| 181 | tools/generate-extended-courses.py | tools/generate-extended-courses.py | DEFER | HIGH | Extended-course generator — MUST NOT emit placeholders. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 182 | tools/german-phase3-content/beginner.html | tools/german-phase3-content/beginner.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 183 | tools/german-phase3-content/common-words.html | tools/german-phase3-content/common-words.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 184 | tools/german-phase3-content/grammar.html | tools/german-phase3-content/grammar.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 185 | tools/german-phase3-content/mistakes.html | tools/german-phase3-content/mistakes.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 186 | tools/german-phase3-content/numbers.html | tools/german-phase3-content/numbers.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 187 | tools/german-phase3-content/pronunciation.html | tools/german-phase3-content/pronunciation.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 188 | tools/german-phase3-content/reading.html | tools/german-phase3-content/reading.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 189 | tools/german-phase3-content/speaking-alone.html | tools/german-phase3-content/speaking-alone.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 190 | tools/german-phase3-content/travel.html | tools/german-phase3-content/travel.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 191 | tools/german-phase3-content/vs-hindi.html | tools/german-phase3-content/vs-hindi.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 192 | tools/header-nav-cleanup.py | tools/header-nav-cleanup.py | DEFER | HIGH | Idempotent removal of 'Learn' and 'Become a Tutor' from ALL header | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 193 | tools/hi-b3-source/hi-b3-level.json | tools/hi-b3-source/hi-b3-level.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 194 | tools/hi-b3-source/hi-b3-unit1.json | tools/hi-b3-source/hi-b3-unit1.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 195 | tools/hi-b3-source/hi-b3-unit2.json | tools/hi-b3-source/hi-b3-unit2.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 196 | tools/hi-b3-source/hi-b3-unit3.json | tools/hi-b3-source/hi-b3-unit3.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 197 | tools/hindi-ext-content/c3.py | tools/hindi-ext-content/c3.py | KEEP | HIGH | Hindi C3 — EXPERT: Hindi in the wild (media, satire, regional colour). | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 198 | tools/hindi-ext-content/c4.py | tools/hindi-ext-content/c4.py | KEEP | HIGH | Hindi C4 — SCHOLAR: literary reading, the grammar of words, academic writing. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 199 | tools/hindi-ext-content/c5.py | tools/hindi-ext-content/c5.py | KEEP | HIGH | Hindi C5 — MASTER: translation craft, public oratory, teaching and the classics. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 200 | tools/hindi-foundation-content.py | tools/hindi-foundation-content.py | KEEP | HIGH | EkGuru — Hindi Foundation (हिंदी की नींव): the content. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 201 | tools/hindi-halfsteps-content.py | tools/hindi-halfsteps-content.py | KEEP | HIGH | Authored content for the Hindi half-step rungs, as data. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 202 | tools/hindi-phase3-content.txt | tools/hindi-phase3-content.txt | KEEP | MEDIUM | Authored Hindi Phase 3 article source; not generic build infrastructure. | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| 203 | tools/idle-live-final.py | tools/idle-live-final.py | DEFER | HIGH | Phase 3 §21 — idle / recovery final gate. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 204 | tools/indian-english.py | tools/indian-english.py | DEFER | HIGH | EkGuru: keep the English copy in Indian English. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 205 | tools/inject-ads.py | tools/inject-ads.py | KEEP | HIGH | EkGuru — THE AD POLICY: which pages may load the ad script, and which may not. | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 206 | tools/inject-advanced-seo.py | tools/inject-advanced-seo.py | DEFER | HIGH | EkGuru — Advanced SEO per Page v300 | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 207 | tools/inject-consent.py | tools/inject-consent.py | KEEP | HIGH | Inject js/cookie-consent.js into every HTML page (idempotent). | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 208 | tools/inject-flashcards.py | tools/inject-flashcards.py | KEEP | HIGH | Inject the PHASE 9 flashcard lab into every practice page that has a deck. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 209 | tools/inject-modern.py | tools/inject-modern.py | DEFER | HIGH | EkGuru — Inject Modern JS v300 | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 210 | tools/inject-questions-api.py | tools/inject-questions-api.py | KEEP | HIGH | Own the question-api tag on explicit question-rendering pages only. | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 211 | tools/inject-recovery.py | tools/inject-recovery.py | DEFER | HIGH | Inject js/recovery.js into every HTML page (idempotent). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 212 | tools/inject-storybook.py | tools/inject-storybook.py | KEEP | HIGH | EkGuru — STORYBOOK INJECTOR (v143). | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 213 | tools/lang-data/bengali.json | tools/lang-data/bengali.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 214 | tools/lang-data/gujarati.json | tools/lang-data/gujarati.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 215 | tools/lang-data/kannada.json | tools/lang-data/kannada.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 216 | tools/lang-data/malayalam.json | tools/lang-data/malayalam.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 217 | tools/lang-data/marathi.json | tools/lang-data/marathi.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 218 | tools/lang-data/modules/bn-education.json | tools/lang-data/modules/bn-education.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 219 | tools/lang-data/modules/bn-festivals.json | tools/lang-data/modules/bn-festivals.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 220 | tools/lang-data/modules/bn-health.json | tools/lang-data/modules/bn-health.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 221 | tools/lang-data/modules/bn-home.json | tools/lang-data/modules/bn-home.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 222 | tools/lang-data/modules/bn-office.json | tools/lang-data/modules/bn-office.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 223 | tools/lang-data/modules/bn-weather.json | tools/lang-data/modules/bn-weather.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 224 | tools/lang-data/modules/gj-education.json | tools/lang-data/modules/gj-education.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 225 | tools/lang-data/modules/gj-festivals.json | tools/lang-data/modules/gj-festivals.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 226 | tools/lang-data/modules/gj-health.json | tools/lang-data/modules/gj-health.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 227 | tools/lang-data/modules/gj-home.json | tools/lang-data/modules/gj-home.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 228 | tools/lang-data/modules/gj-office.json | tools/lang-data/modules/gj-office.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 229 | tools/lang-data/modules/gj-weather.json | tools/lang-data/modules/gj-weather.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 230 | tools/lang-data/modules/hi-education.json | tools/lang-data/modules/hi-education.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 231 | tools/lang-data/modules/hi-festivals.json | tools/lang-data/modules/hi-festivals.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 232 | tools/lang-data/modules/hi-health.json | tools/lang-data/modules/hi-health.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 233 | tools/lang-data/modules/hi-home.json | tools/lang-data/modules/hi-home.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 234 | tools/lang-data/modules/hi-office.json | tools/lang-data/modules/hi-office.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 235 | tools/lang-data/modules/hi-weather.json | tools/lang-data/modules/hi-weather.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 236 | tools/lang-data/modules/kn-education.json | tools/lang-data/modules/kn-education.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 237 | tools/lang-data/modules/kn-festivals.json | tools/lang-data/modules/kn-festivals.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 238 | tools/lang-data/modules/kn-health.json | tools/lang-data/modules/kn-health.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 239 | tools/lang-data/modules/kn-home.json | tools/lang-data/modules/kn-home.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 240 | tools/lang-data/modules/kn-office.json | tools/lang-data/modules/kn-office.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 241 | tools/lang-data/modules/kn-weather.json | tools/lang-data/modules/kn-weather.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 242 | tools/lang-data/modules/ml-education.json | tools/lang-data/modules/ml-education.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 243 | tools/lang-data/modules/ml-festivals.json | tools/lang-data/modules/ml-festivals.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 244 | tools/lang-data/modules/ml-health.json | tools/lang-data/modules/ml-health.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 245 | tools/lang-data/modules/ml-home.json | tools/lang-data/modules/ml-home.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 246 | tools/lang-data/modules/ml-office.json | tools/lang-data/modules/ml-office.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 247 | tools/lang-data/modules/ml-weather.json | tools/lang-data/modules/ml-weather.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 248 | tools/lang-data/modules/mr-education.json | tools/lang-data/modules/mr-education.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 249 | tools/lang-data/modules/mr-festivals.json | tools/lang-data/modules/mr-festivals.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 250 | tools/lang-data/modules/mr-health.json | tools/lang-data/modules/mr-health.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 251 | tools/lang-data/modules/mr-home.json | tools/lang-data/modules/mr-home.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 252 | tools/lang-data/modules/mr-office.json | tools/lang-data/modules/mr-office.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 253 | tools/lang-data/modules/mr-weather.json | tools/lang-data/modules/mr-weather.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 254 | tools/lang-data/modules/pj-education.json | tools/lang-data/modules/pj-education.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 255 | tools/lang-data/modules/pj-festivals.json | tools/lang-data/modules/pj-festivals.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 256 | tools/lang-data/modules/pj-health.json | tools/lang-data/modules/pj-health.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 257 | tools/lang-data/modules/pj-home.json | tools/lang-data/modules/pj-home.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 258 | tools/lang-data/modules/pj-office.json | tools/lang-data/modules/pj-office.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 259 | tools/lang-data/modules/pj-weather.json | tools/lang-data/modules/pj-weather.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 260 | tools/lang-data/modules/ta-education.json | tools/lang-data/modules/ta-education.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 261 | tools/lang-data/modules/ta-festivals.json | tools/lang-data/modules/ta-festivals.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 262 | tools/lang-data/modules/ta-health.json | tools/lang-data/modules/ta-health.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 263 | tools/lang-data/modules/ta-home.json | tools/lang-data/modules/ta-home.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 264 | tools/lang-data/modules/ta-office.json | tools/lang-data/modules/ta-office.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 265 | tools/lang-data/modules/ta-weather.json | tools/lang-data/modules/ta-weather.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 266 | tools/lang-data/modules/te-education.json | tools/lang-data/modules/te-education.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 267 | tools/lang-data/modules/te-festivals.json | tools/lang-data/modules/te-festivals.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 268 | tools/lang-data/modules/te-health.json | tools/lang-data/modules/te-health.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 269 | tools/lang-data/modules/te-home.json | tools/lang-data/modules/te-home.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 270 | tools/lang-data/modules/te-office.json | tools/lang-data/modules/te-office.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 271 | tools/lang-data/modules/te-weather.json | tools/lang-data/modules/te-weather.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 272 | tools/lang-data/modules/ur-education.json | tools/lang-data/modules/ur-education.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 273 | tools/lang-data/modules/ur-festivals.json | tools/lang-data/modules/ur-festivals.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 274 | tools/lang-data/modules/ur-health.json | tools/lang-data/modules/ur-health.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 275 | tools/lang-data/modules/ur-home.json | tools/lang-data/modules/ur-home.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 276 | tools/lang-data/modules/ur-office.json | tools/lang-data/modules/ur-office.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 277 | tools/lang-data/modules/ur-weather.json | tools/lang-data/modules/ur-weather.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 278 | tools/lang-data/punjabi.json | tools/lang-data/punjabi.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 279 | tools/lang-data/tamil.json | tools/lang-data/tamil.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 280 | tools/lang-data/telugu.json | tools/lang-data/telugu.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 281 | tools/lang-data/urdu.json | tools/lang-data/urdu.json | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 282 | tools/langpacks_194_af1.py | tools/langpacks_194_af1.py | KEEP | MEDIUM | 194-country program, batch C3 — Madagascar, Rwanda, Burundi, Zimbabwe, Somalia (authored, not MT). | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 283 | tools/langpacks_194_af2.py | tools/langpacks_194_af2.py | KEEP | MEDIUM | 194-country program, batch C4 — Lesotho, South Sudan, Eswatini (authored, not MT). | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 284 | tools/langpacks_194_af3.py | tools/langpacks_194_af3.py | KEEP | MEDIUM | 194-country program, batch C5 — Eritrea, Ethiopia, Haiti (authored, not MT). | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 285 | tools/langpacks_194_as1.py | tools/langpacks_194_as1.py | KEEP | MEDIUM | 194-country program, batch B1 — Central Asia + Mongolia + Myanmar + Cambodia (authored, not MT). | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 286 | tools/langpacks_194_as2.py | tools/langpacks_194_as2.py | KEEP | MEDIUM | 194-country program, batch B2 — Laos, Nepal, Sri Lanka, Maldives, Afghanistan, Bhutan, Timor, PH (authored, not MT). | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 287 | tools/langpacks_194_eu1.py | tools/langpacks_194_eu1.py | KEEP | MEDIUM | 194-country program, batch A1 — Europe north/west/central (authored, not MT). | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 288 | tools/langpacks_194_eu2.py | tools/langpacks_194_eu2.py | KEEP | MEDIUM | 194-country program, batch A2 — Central/Eastern/Southeast Europe (authored, not MT). | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 289 | tools/langpacks_194_eu3.py | tools/langpacks_194_eu3.py | KEEP | MEDIUM | 194-country program, batch A3 — Balkans + Baltics (authored, not MT). | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 290 | tools/langpacks_194_eu4.py | tools/langpacks_194_eu4.py | KEEP | MEDIUM | 194-country program, batch A4 — West Europe islands + Caucasus + Belarus (authored, not MT). | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 291 | tools/langpacks_194_oc1a.py | tools/langpacks_194_oc1a.py | KEEP | MEDIUM | 194-country program, batch C1a — Samoa + Tonga (authored, not MT). | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 292 | tools/langpacks_194_oc1b.py | tools/langpacks_194_oc1b.py | KEEP | MEDIUM | 194-country program, batch C1b — Marshall Islands, Kiribati, Tuvalu (authored, not MT). | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 293 | tools/langpacks_194_oc2.py | tools/langpacks_194_oc2.py | KEEP | MEDIUM | 194-country program, batch C2 — Nauru, Palau, Seychelles, New Zealand (authored, not MT). | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 294 | tools/langpacks_extra.py | tools/langpacks_extra.py | KEEP | HIGH | Authored additional language starter packs imported by build-lang-packs.py; static source bank. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 295 | tools/langsync.js | tools/langsync.js | KEEP | HIGH | EkGuru — TUTOR SCRIPT SYNC -------------------------------------------------------------------------- Gives every page that loads the tutor registry a <script> tag for every tutor in it — English pages, the six translated markets, join.html, find-tutors.html, admin.html, all of t | Protected tutor/booking/feed behavior or public-roster output ownership. Preserve integration and generation contracts; no move proposed. |
| 296 | tools/language-gate.py | tools/language-gate.py | KEEP | HIGH | U4 language quality gate. Reports honestly; never edits a page and never changes indexing. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 297 | tools/learn-tools-audit.py | tools/learn-tools-audit.py | DEFER | HIGH | EkGuru — Learn/Tools quality baseline (static crawl). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 298 | tools/lib/__init__.py | tools/lib/__init__.py | KEEP | MEDIUM | Shared import/API module; exports and import edges recorded below. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 299 | tools/lib/appscript_health.py | tools/lib/appscript_health.py | KEEP | MEDIUM | Classification for Apps Script GET probes used in CI. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 300 | tools/lib/bank_builder.py | tools/lib/bank_builder.py | KEEP | HIGH | Authored extra-level lesson bank/DSL assembly with tools.lib.* import relationships; not interchangeable generic utilities. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 301 | tools/lib/country_quality.py | tools/lib/country_quality.py | KEEP | MEDIUM | Deterministic country-language relationship publication states. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 302 | tools/lib/en_in.py | tools/lib/en_in.py | KEEP | MEDIUM | Indian English (en-IN) word map for EkGuru's English copy. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 303 | tools/lib/extended_banks.py | tools/lib/extended_banks.py | KEEP | HIGH | Authored extra-level lesson bank/DSL assembly with tools.lib.* import relationships; not interchangeable generic utilities. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 304 | tools/lib/extended_banks_asia.py | tools/lib/extended_banks_asia.py | KEEP | HIGH | Authored extra-level lesson bank/DSL assembly with tools.lib.* import relationships; not interchangeable generic utilities. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 305 | tools/lib/extended_banks_batch2.py | tools/lib/extended_banks_batch2.py | KEEP | HIGH | Authored extra-level lesson bank/DSL assembly with tools.lib.* import relationships; not interchangeable generic utilities. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 306 | tools/lib/extended_banks_batch3.py | tools/lib/extended_banks_batch3.py | KEEP | HIGH | Authored extra-level lesson bank/DSL assembly with tools.lib.* import relationships; not interchangeable generic utilities. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 307 | tools/lib/extended_banks_batch4.py | tools/lib/extended_banks_batch4.py | KEEP | HIGH | Authored extra-level lesson bank/DSL assembly with tools.lib.* import relationships; not interchangeable generic utilities. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 308 | tools/lib/extended_banks_batch5.py | tools/lib/extended_banks_batch5.py | KEEP | HIGH | Authored extra-level lesson bank/DSL assembly with tools.lib.* import relationships; not interchangeable generic utilities. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 309 | tools/lib/extended_banks_batch6.py | tools/lib/extended_banks_batch6.py | KEEP | HIGH | Authored extra-level lesson bank/DSL assembly with tools.lib.* import relationships; not interchangeable generic utilities. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 310 | tools/lib/extended_banks_core.py | tools/lib/extended_banks_core.py | KEEP | HIGH | Authored extra-level lesson bank/DSL assembly with tools.lib.* import relationships; not interchangeable generic utilities. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 311 | tools/lib/extended_banks_rest.py | tools/lib/extended_banks_rest.py | KEEP | HIGH | Authored extra-level lesson bank/DSL assembly with tools.lib.* import relationships; not interchangeable generic utilities. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 312 | tools/lib/extended_banks_world.py | tools/lib/extended_banks_world.py | KEEP | HIGH | Authored extra-level lesson bank/DSL assembly with tools.lib.* import relationships; not interchangeable generic utilities. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 313 | tools/lib/flashcard_section.py | tools/lib/flashcard_section.py | KEEP | MEDIUM | Shared flashcard section for the practice labs (PHASE 9). | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 314 | tools/lib/hindi_learner_offer.py | tools/lib/hindi_learner_offer.py | KEEP | MEDIUM | Shared, non-promissory free-learning / independent-Hindi-tutoring next step. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 315 | tools/lib/placeholders.py | tools/lib/placeholders.py | KEEP | MEDIUM | Detect manufactured course placeholders. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 316 | tools/lib/site-data.js | tools/lib/site-data.js | KEEP | MEDIUM | EkGuru — shared site data loader (build side) --------------------------------------------------------- One loader for every generator that needs the tutor roster: the tutors come out exactly as the browser will see them. It runs the real files in a vm sandbox, in the real order: | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 317 | tools/lib/speech_tags.py | tools/lib/speech_tags.py | KEEP | MEDIUM | Canonical BCP-47 speech tags for the published languages. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 318 | tools/lib/text.py | tools/lib/text.py | KEEP | MEDIUM | Unicode-aware deterministic proxies for audit; never claim they replace a native editor. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 319 | tools/lib/ultra_content.py | tools/lib/ultra_content.py | KEEP | MEDIUM | Shared public traversal / own-content HTML parser plus JSON read/write helpers; save_json can create directories and write files. Its read-only header is not a transitive execution guarantee. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 320 | tools/lib/validate-language-schema.mjs | tools/lib/validate-language-schema.mjs | KEEP | MEDIUM | Ajv (JSON Schema 2020-12) validation for the registry rows and the tiered content. Prints compact JSON to stdout. Usage: node tools/lib/validate-language-schema.mjs <input.json> input: { registry:[rows], t1:{code:[{rung,file}]}, t2:{code:file\|normalized}, t3:{code:file} }  | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 321 | tools/lib/zero-state.js | tools/lib/zero-state.js | KEEP | MEDIUM | EkGuru — ZERO-TUTOR STATE (shared by the generators) --------------------------------------------------------- U0, 30 Sep 2026. The owner's decision: while the Google Sheet marks every tutor active=no, NO tutor is public anywhere — and every place that used to list tutors says so | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 322 | tools/live-browser-matrix.py | tools/live-browser-matrix.py | DEFER | HIGH | Phase 3 §4 — live browser matrix against https://ekguru.shop/. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 323 | tools/live-crawl.js | tools/live-crawl.js | DEFER | HIGH | EkGuru — LIVE reachability + URL inventory. Walks the local tree, maps every HTML page to its production URL, then requests each one against https://ekguru.shop/ and records the HTTP status. Outputs: reports/url-inventory.json { base, total, urls[], generated } reports/live-reach | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 324 | tools/live-monitor.js | tools/live-monitor.js | DEFER | HIGH | EkGuru — Live production monitor. Checks every operational surface and records status + latency. States: GREEN / YELLOW / RED / UNKNOWN. UNKNOWN is never reported as GREEN. Output: reports/monitor.json { generated, checks[], summary{} }  | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 325 | tools/live-perf.py | tools/live-perf.py | DEFER | HIGH | Phase 3 §19 — real production performance (Chromium Navigation/Resource timing). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 326 | tools/live-route-check.py | tools/live-route-check.py | DEFER | HIGH | Phase 3 §3 — verify production routes from OUTSIDE the local server. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 327 | tools/live-seo-gate.py | tools/live-seo-gate.py | KEEP | HIGH | Fail-closed HTTP search-discovery probes, not a ranking/indexing claim. | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| 328 | tools/localise-speaker-labels.py | tools/localise-speaker-labels.py | DEFER | HIGH | Put the dialogue role labels of a shipped course into its own language. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 329 | tools/make-copyright-page.py | tools/make-copyright-page.py | DEFER | HIGH | Generate copyright/index.html from the terms/ shell (identical head, | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 330 | tools/make-email-reports.py | tools/make-email-reports.py | DEFER | HIGH | Write credential-free mail inventory from tracked release behavior. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 331 | tools/make-email-ultra-reports.py | tools/make-email-ultra-reports.py | DEFER | HIGH | EkGuru — build the Email ULTRA report set (v100). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 332 | tools/make-master-audit-fast.py | tools/make-master-audit-fast.py | DEFER | HIGH | Fast version — walk once, reuse | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 333 | tools/make-master-audit.py | tools/make-master-audit.py | DEFER | HIGH | EkGuru — MASTER AUDIT GENERATOR | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 334 | tools/make-p0-reports.py | tools/make-p0-reports.py | DEFER | HIGH | Generate reports/interaction-lifecycle-audit.json and reports/idle-interaction-regression.json. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 335 | tools/make-phase2-reports.py | tools/make-phase2-reports.py | DEFER | HIGH | Generate the Phase-2 required reports from measured evidence already on disk. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 336 | tools/make-phase3-baseline.py | tools/make-phase3-baseline.py | DEFER | HIGH | Phase 3 baseline — authoritative state before any Phase 3 change. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 337 | tools/make-phase3-final.py | tools/make-phase3-final.py | DEFER | HIGH | Phase 3 §22/§23/§24 — final gate, release manifest, owner handoff. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 338 | tools/make-phase3-reports.py | tools/make-phase3-reports.py | DEFER | HIGH | Phase 3 — generate the deterministic/static reports from measured evidence. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 339 | tools/make-phase4-reports.py | tools/make-phase4-reports.py | DEFER | HIGH | Phase 4 §25/§34 — consolidation classification, 26-item final gate, | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 340 | tools/make-phase5-reports.py | tools/make-phase5-reports.py | DEFER | HIGH | Phase 5 — assemble the final gate + UX gap report from the evidence files. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 341 | tools/make-requirements.py | tools/make-requirements.py | DEFER | HIGH | Generate reports/master-requirements.json — the cumulative checklist merging | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 342 | tools/make-requirements2.py | tools/make-requirements2.py | DEFER | HIGH | Append the requirements from the 4 newest command files to the cumulative | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 343 | tools/make-sweep-reports.py | tools/make-sweep-reports.py | DEFER | HIGH | Generate the Zero-Missing-Gap sweep deliverables + runbook + release | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 344 | tools/make-tutor-row.py | tools/make-tutor-row.py | KEEP | HIGH | EkGuru — build the LOCAL, paste-ready tutors CSV for the Google Sheet. | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 345 | tools/materials_b.py | tools/materials_b.py | KEEP | HIGH | Authored material-page resource records imported by build-materials.py; retained source, not standalone CLI tooling. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 346 | tools/materials_c.py | tools/materials_c.py | KEEP | HIGH | Authored material-page resource records imported by build-materials.py; retained source, not standalone CLI tooling. | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| 347 | tools/measure-header.py | tools/measure-header.py | DEFER | HIGH | Measure EkGuru header geometry with real Chromium via Playwright. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 348 | tools/merge-email-requirements.py | tools/merge-email-requirements.py | DEFER | HIGH | Merge the critical email/booking routing/failover command into | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 349 | tools/merge-remaining-requirements.py | tools/merge-remaining-requirements.py | DEFER | HIGH | Merge the 7 remaining (previously unrepresented) command files into | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 350 | tools/normalise-romanisation.py | tools/normalise-romanisation.py | KEEP | HIGH | One romanisation scheme per course file. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 351 | tools/normalize-lang-data-classifiers.py | tools/normalize-lang-data-classifiers.py | DEFER | HIGH | One-off: give every Indian starter pack's counting examples the shape the rest of the file uses. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 352 | tools/patch-header-css.py | tools/patch-header-css.py | DEFER | HIGH | Apply the measured header-layout fix to css/style.min.css. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 353 | tools/patch-language-voice-controls.py | tools/patch-language-voice-controls.py | KEEP | HIGH | Add language-aware speaker markup to scoped Indian course and topic HTML. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 354 | tools/phase2-baseline.py | tools/phase2-baseline.py | DEFER | HIGH | Phase-2 baseline: measure the current repository with real numbers. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 355 | tools/phase3-dynamic-tests.py | tools/phase3-dynamic-tests.py | DEFER | HIGH | Phase 3 dynamic tests (real Chromium): | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 356 | tools/phase3-security-scan.py | tools/phase3-security-scan.py | DEFER | HIGH | Phase 3 §20 — security / privacy final scan. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 357 | tools/phase4-browser-gate.py | tools/phase4-browser-gate.py | DEFER | HIGH | Phase 4 §29–31 — real-browser matrix + idle regression for the Learn Hindi structure. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 358 | tools/privacy.js | tools/privacy.js | KEEP | HIGH | EkGuru — Privacy & secret/PII scanner (node tools/privacy.js [--sheets] [--live]) Classifies data into PUBLIC / INTERNAL / SENSITIVE / SECRET and flags anything that must never ship to the public site. Modes: (default) scan the repository (HTML/JS/CSS/JSON/XML) for secrets + PII  | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| 359 | tools/probe-providers.py | tools/probe-providers.py | KEEP | HIGH | EkGuru — direct live probe of every mail provider, from a REAL browser context. | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 360 | tools/qa-perf-a11y.py | tools/qa-perf-a11y.py | DEFER | HIGH | EkGuru — Performance + Accessibility final gate (real Chromium). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 361 | tools/quarantine-country-funnels.py | tools/quarantine-country-funnels.py | KEEP | HIGH | Deterministically quarantine research-only location/language surfaces. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 362 | tools/quarantine-language-surfaces.py | tools/quarantine-language-surfaces.py | KEEP | HIGH | Keep unsupported language tracks and duplicate hubs out of publication. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 363 | tools/quarantine-tutor-drafts.py | tools/quarantine-tutor-drafts.py | KEEP | HIGH | Keep hidden/incomplete tutor profile pages out of public discovery. | Protected tutor/booking/feed behavior or public-roster output ownership. Preserve integration and generation contracts; no move proposed. |
| 364 | tools/release-decision.js | tools/release-decision.js | DEFER | HIGH | EkGuru — Release decision. Aggregates every gate report and returns the exact GO/NO-GO matrix the final-readiness command requires. Output: reports/release-decision.json v102 honesty rules (13 Sep 2026): - DATA, STUDENT_EMAIL client-token and CONTENT page-count are read LIVE from | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 365 | tools/render-og-images.mjs | tools/render-og-images.mjs | DEFER | HIGH | Render the generated Open Graph SVG batch with the pinned resvg renderer.  | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 366 | tools/render-report.js | tools/render-report.js | DEFER | HIGH | Renders every email template fixture and prints a JSON summary the Python report builder consumes. Single source of truth: the code.  | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 367 | tools/repair-extended-levels.py | tools/repair-extended-levels.py | DEFER | HIGH | Replace placeholder extra-level (and unpublished-language) JSON. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 368 | tools/repair-phase1-advanced-glosses.py | tools/repair-phase1-advanced-glosses.py | KEEP | HIGH | Replace generated C1/C2 phrase-fragment labels with contextual glosses. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 369 | tools/run-phase7c-pipeline.py | tools/run-phase7c-pipeline.py | KEEP | HIGH | Phase 7C §47 — master generation + QA pipeline. | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 370 | tools/security-audit.js | tools/security-audit.js | DEFER | HIGH | EkGuru — Security final gate. Audits what a static GitHub Pages site can control (headers it can't set are reported honestly as NOT_CONTROLLABLE, not as PASS), dependency surface, secrets, source maps, open redirects. Output: reports/security-audit.json  | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 371 | tools/seocheck.js | tools/seocheck.js | KEEP | HIGH | EkGuru — SEO checker (build side). Crawls the static tree, checks every internal link resolves, finds orphan pages, and verifies the sitemap. Output: reports/seo.json { pass, critical, warnings, pages, sitemapUrls, sitemapFiles, brokenLinks, orphans } Run: node tools/seocheck.js  | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| 372 | tools/sheet-fetch.js | tools/sheet-fetch.js | KEEP | HIGH | EkGuru — SHARED PUBLISHED-SHEET FETCH + PARSE --------------------------------------------------------- One implementation of "read a published Google Sheet tab" for every consumer: tools/sheetsync.js (build), the offline fixture path, tests/integration/test-data-sources.py's Nod | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 373 | tools/sheetsync.js | tools/sheetsync.js | KEEP | HIGH | EkGuru — Sheets sync (build side). Regenerates js/tutors/_overrides.js from the LIVE production Google Sheets. This is the generator the repo has been missing (referenced in the _overrides.js header and in js/sheet.js comments). It ports the SAME FIELDS transforms as js/sheet.js  | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 374 | tools/spanish-phase3-content/beginner.html | tools/spanish-phase3-content/beginner.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 375 | tools/spanish-phase3-content/common-words.html | tools/spanish-phase3-content/common-words.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 376 | tools/spanish-phase3-content/grammar.html | tools/spanish-phase3-content/grammar.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 377 | tools/spanish-phase3-content/mistakes.html | tools/spanish-phase3-content/mistakes.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 378 | tools/spanish-phase3-content/numbers.html | tools/spanish-phase3-content/numbers.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 379 | tools/spanish-phase3-content/pronunciation.html | tools/spanish-phase3-content/pronunciation.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 380 | tools/spanish-phase3-content/reading.html | tools/spanish-phase3-content/reading.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 381 | tools/spanish-phase3-content/speaking-alone.html | tools/spanish-phase3-content/speaking-alone.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 382 | tools/spanish-phase3-content/travel.html | tools/spanish-phase3-content/travel.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 383 | tools/spanish-phase3-content/vs-hindi.html | tools/spanish-phase3-content/vs-hindi.html | KEEP | HIGH | Protected authored course/module source; semantics excluded from migration audit. | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| 384 | tools/sweep-header-geometry.py | tools/sweep-header-geometry.py | DEFER | HIGH | Fine-grained header geometry sweep (v102). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 385 | tools/templates/country-funnel-base.tmpl | tools/templates/country-funnel-base.tmpl | KEEP | MEDIUM | Country-funnel HTML scaffold with embedded public/runtime references; build input, not a published route. | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| 386 | tools/test-ad-policy.mjs | tools/test-ad-policy.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/regression/test-ad-policy.mjs. No test assertions live here. import "../tests/regression/test-ad-policy.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 387 | tools/test-adaptive-practice.js | tools/test-adaptive-practice.js | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/regression/test-adaptive-practice.js. No test assertions live here. require("../tests/regression/test-adaptive-practice.js"); | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 388 | tools/test-affiliate-disclosure.mjs | tools/test-affiliate-disclosure.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/regression/test-affiliate-disclosure.mjs. No test assertions live here. import "../tests/regression/test-affiliate-disclosure.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 389 | tools/test-application-backend.mjs | tools/test-application-backend.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/integration/test-application-backend.mjs. No test assertions live here. import "../tests/integration/test-application-backend.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 390 | tools/test-copy-index.mjs | tools/test-copy-index.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/regression/test-copy-index.mjs. No test assertions live here. import "../tests/regression/test-copy-index.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 391 | tools/test-course-levels.mjs | tools/test-course-levels.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/regression/test-course-levels.mjs. No test assertions live here. import "../tests/regression/test-course-levels.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 392 | tools/test-email-security.js | tools/test-email-security.js | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/integration/test-email-security.js. No test assertions live here. require("../tests/integration/test-email-security.js"); | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 393 | tools/test-email-system.js | tools/test-email-system.js | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/integration/test-email-system.js. No test assertions live here. require("../tests/integration/test-email-system.js"); | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 394 | tools/test-join-css-visibility.mjs | tools/test-join-css-visibility.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/regression/test-join-css-visibility.mjs. No test assertions live here. import "../tests/regression/test-join-css-visibility.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 395 | tools/test-join-wizard-nav.mjs | tools/test-join-wizard-nav.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/regression/test-join-wizard-nav.mjs. No test assertions live here. import "../tests/regression/test-join-wizard-nav.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 396 | tools/test-join-wizard.mjs | tools/test-join-wizard.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/regression/test-join-wizard.mjs. No test assertions live here. import "../tests/regression/test-join-wizard.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 397 | tools/test-live-feed.js | tools/test-live-feed.js | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/integration/test-live-feed.js. No test assertions live here. require("../tests/integration/test-live-feed.js"); | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 398 | tools/test-question-api.mjs | tools/test-question-api.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/regression/test-question-api.mjs. No test assertions live here. import "../tests/regression/test-question-api.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 399 | tools/test-reviews-fallback.js | tools/test-reviews-fallback.js | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/integration/test-reviews-fallback.js. No test assertions live here. require("../tests/integration/test-reviews-fallback.js"); | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 400 | tools/test-routing.js | tools/test-routing.js | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/integration/test-routing.js. No test assertions live here. require("../tests/integration/test-routing.js"); | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 401 | tools/test-sheet-fetch.mjs | tools/test-sheet-fetch.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/integration/test-sheet-fetch.mjs. No test assertions live here. import "../tests/integration/test-sheet-fetch.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 402 | tools/test-sheet-only-bake.mjs | tools/test-sheet-only-bake.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/integration/test-sheet-only-bake.mjs. No test assertions live here. import "../tests/integration/test-sheet-only-bake.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 403 | tools/test-support-static.mjs | tools/test-support-static.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/regression/test-support-static.mjs. No test assertions live here. import "../tests/regression/test-support-static.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 404 | tools/test-theme-contrast.mjs | tools/test-theme-contrast.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/regression/test-theme-contrast.mjs. No test assertions live here. import "../tests/regression/test-theme-contrast.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 405 | tools/test-tools-functional.py | tools/test-tools-functional.py | COMPATIBILITY LAUNCHER | MEDIUM | Compatibility entrypoint only; canonical test: tests/regression/test-tools-functional.py. No test assertions live here. | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 406 | tools/test-tutor-activation.mjs | tools/test-tutor-activation.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/integration/test-tutor-activation.mjs. No test assertions live here. import "../tests/integration/test-tutor-activation.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 407 | tools/test-usability-home.mjs | tools/test-usability-home.mjs | COMPATIBILITY LAUNCHER | MEDIUM | // Compatibility entrypoint only; canonical test: tests/regression/test-usability-home.mjs. No test assertions live here. import "../tests/regression/test-usability-home.mjs"; | Existing completed-restructure compatibility interface; retain exact launcher and canonical test path, forward arguments/exit behavior; no new move. |
| 408 | tools/topic-meta.json | tools/topic-meta.json | KEEP | MEDIUM | Hindi topic metadata consumed by the structure builder. | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| 409 | tools/trend-analysis.py | tools/trend-analysis.py | KEEP | HIGH | Daily demand-vs-coverage analysis for EkGuru's Hindi funnel. | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| 410 | tools/ultra/contract.py | tools/ultra/contract.py | KEEP | HIGH | Immutable owner indexing/canonical contract check and explicit original-Git-object restoration mode. | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 411 | tools/unfreeze-country-languages.py | tools/unfreeze-country-languages.py | DEFER | HIGH | Deterministically unfreeze owner-approved country-language clusters. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 412 | tools/update-editorial-metadata.py | tools/update-editorial-metadata.py | KEEP | HIGH | Truthful 'Updated' dates. Own-content hashes exclude shared chrome, controls and hidden markup, so a rebuild or a | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 413 | tools/validate-inventory.py | tools/validate-inventory.py | KEEP | HIGH | EkGuru — language-inventory validator + skeleton generator. | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| 414 | tools/validate-sheets.py | tools/validate-sheets.py | DEFER | HIGH | Phase 3 §7/§8/§9 — validate the owner's live-sheets CSVs, diff them against | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 415 | tools/verify-hindi-search.py | tools/verify-hindi-search.py | DEFER | HIGH | Phase 6 §16 — end-to-end fuzzy search verification (real Chromium). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 416 | tools/verify-hindi-typing.py | tools/verify-hindi-typing.py | DEFER | HIGH | Phase 7B Gate-C verification: toolbox/hindi-typing transliteration in real Chromium. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 417 | tools/weekly-guard.sh | tools/weekly-guard.sh | KEEP | HIGH | #!/usr/bin/env bash # EkGuru weekly AdSense + SEO guard (plan PART C, Phase 10). # # bash tools/weekly-guard.sh # from the repository root # STRICT_LIVE=1 bash tools/weekly-guard.sh # treat Cloudflare challenge as hard fail # | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| 418 | tools/wire-token.py | tools/wire-token.py | KEEP | HIGH | EkGuru — wire the Apps Script mail token into the client (v99). | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| 419 | tools/write-final-gate.py | tools/write-final-gate.py | DEFER | HIGH | Phase 6 §35–36 — assemble phase6-final-gate.json from the reports that the | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 420 | tools/write-phase6-reports.py | tools/write-phase6-reports.py | DEFER | HIGH | Phase 6 §35 — assemble the two remaining derived reports from real outputs: | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 421 | tools/write-phase7-reports.py | tools/write-phase7-reports.py | DEFER | HIGH | Phase 7 §32–34 — assemble audio-provider report, learning QA aggregate, | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 422 | tools/write-phase7b-final.py | tools/write-phase7b-final.py | DEFER | HIGH | Phase 7B §29/§30/§31 — final gate, owner fix list, console summary. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 423 | tools/write-phase7c-reports.py | tools/write-phase7c-reports.py | DEFER | HIGH | Phase 7C §55/§56/§57 — required reports (tranche 1) + honest final gate. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 424 | tools/write-phase7c-reports2.py | tools/write-phase7c-reports2.py | DEFER | HIGH | Phase 7C tranches 2-4 — final reports (§55) + final gate (§56). | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 425 | tools/write-zero-hero-evidence.py | tools/write-zero-hero-evidence.py | DEFER | HIGH | Write the 27 Sep 2026 zero-to-hero evidence pack from repository scans. | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| 426 | playwright.config.mjs | playwright.config.mjs | KEEP | MEDIUM | Playwright browser-test configuration and local static HTTP-server registration. | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |
| 427 | sw.js | sw.js | KEEP | HIGH | Public browser service worker: cache shell, offline fetch behavior and cache versions. | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |
| 428 | docs/marketing/ekguru-brand-ad/scripts/assemble_veo_master.py | docs/marketing/ekguru-brand-ad/scripts/assemble_veo_master.py | DEFER | HIGH | EkGuru — Turnkey Veo 3.1 Lite Master Commercial Assembler & Multi-Format Finisher | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| 429 | docs/marketing/ekguru-brand-ad/scripts/compose_music_and_mix.py | docs/marketing/ekguru-brand-ad/scripts/compose_music_and_mix.py | DEFER | HIGH | Compose an original, 100% royalty-free Indian-fusion cinematic commercial score (48kHz stereo) | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| 430 | docs/marketing/ekguru-brand-ad/scripts/render_9x16_reel_shorts.py | docs/marketing/ekguru-brand-ad/scripts/render_9x16_reel_shorts.py | DEFER | HIGH | Render the 9:16 Vertical (1080x1920, 30fps) Instagram Reels & YouTube Shorts suite: | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| 431 | docs/marketing/ekguru-brand-ad/scripts/render_brand_graphics.mjs | docs/marketing/ekguru-brand-ad/scripts/render_brand_graphics.mjs | DEFER | HIGH | Render branded ad SVG/vector graphics to campaign PNG assets using environment-specific /tmp/ad_node Resvg; does not generate website routes. | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| 432 | docs/marketing/ekguru-brand-ad/scripts/render_scene7_and_previz.py | docs/marketing/ekguru-brand-ad/scripts/render_scene7_and_previz.py | DEFER | HIGH | Fast SIMD-C (Pillow sub-pixel BICUBIC box resize) renderer for: | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| 433 | docs/marketing/ekguru-social-campaign/scripts/build_all_in_one_post.py | docs/marketing/ekguru-social-campaign/scripts/build_all_in_one_post.py | DEFER | HIGH | Builds the photographic base canvas and precision HarfBuzz Devanagari paths | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| 434 | docs/marketing/ekguru-social-campaign/scripts/prepare_framed_canvases.py | docs/marketing/ekguru-social-campaign/scripts/prepare_framed_canvases.py | DEFER | HIGH | Prepares pixel-exact photographic base canvases (1080x1350 for Instagram Carousel | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| 435 | docs/marketing/ekguru-social-campaign/scripts/render_all_in_one_post.mjs | docs/marketing/ekguru-social-campaign/scripts/render_all_in_one_post.mjs | DEFER | HIGH | Assemble editable all-in-one social-post SVG and render its PNG from campaign assets using environment-specific Resvg. | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| 436 | docs/marketing/ekguru-social-campaign/scripts/render_campaign_assets.mjs | docs/marketing/ekguru-social-campaign/scripts/render_campaign_assets.mjs | DEFER | HIGH | Render campaign-specific editable SVG and raster social graphics to the campaign design/export directories. | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| 437 | docs/marketing/ekguru-social-campaign/scripts/shape_hindi_typography.py | docs/marketing/ekguru-social-campaign/scripts/shape_hindi_typography.py | DEFER | HIGH | Precision OpenType HarfBuzz shaper for mixed Devanagari + Latin editorial copy. | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| 438 | docs/marketing/growth-distribution-2026-11/scripts/build_distribution_kit.js | docs/marketing/growth-distribution-2026-11/scripts/build_distribution_kit.js | DEFER | HIGH | Generate growth-distribution messaging/channel/reel packs and tutor WhatsApp dashboard from public site-data; writes only campaign deliverables. | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| 439 | docs/marketing/growth-distribution-2026-11/scripts/build_remaining_packs.js | docs/marketing/growth-distribution-2026-11/scripts/build_remaining_packs.js | DEFER | HIGH | Builds the remaining copy-paste & tracking packs for Sections 3, 4, 5, 7, 8, 9, and 10 * of DISTRIBUTION-KIT-2026-11-24.md and GROWTH-PLAN-2026-11-24.md, verifying every single * https://ekguru.shop/... URL against the repository filesystem before writing.  | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| 440 | docs/marketing/growth-distribution-2026-11/scripts/build_shorts_and_printables.py | docs/marketing/growth-distribution-2026-11/scripts/build_shorts_and_printables.py | DEFER | HIGH | Render the remaining visual & video deliverables for the Nov 2026 Distribution Kit: | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| 441 | docs/marketing/growth-distribution-2026-11/scripts/build_visual_assets.py | docs/marketing/growth-distribution-2026-11/scripts/build_visual_assets.py | DEFER | HIGH | Build EkGuru claim-safe Open Graph cover (1200x630) and the 3 Official Profile | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| 442 | package.json | package.json | KEEP | MEDIUM | Node development dependency versions and all 16 npm script registrations; start server, offline/live tests and advertising diagnostics. | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |
| 443 | .github/workflows/ci.yml | .github/workflows/ci.yml | KEEP | MEDIUM | PR/main quality pipeline: Node 22/Python 3.11, indexing freeze, generated-layer checks, master build, public surface and offline/live integration/browser tests. | Retain workflow path and all existing commands/assertions. Only the explicit additive offline build-system compatibility test step is proposed; no service/dependency/deployment changes. |
| 444 | .github/workflows/course-health.yml | .github/workflows/course-health.yml | KEEP | MEDIUM | Scheduled/manual course and language health checks, with GitHub issue creation/update behavior. | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |
| 445 | .github/workflows/live-guard.yml | .github/workflows/live-guard.yml | KEEP | MEDIUM | Scheduled/manual weekly advertising/SEO guard and live search-discovery probes; remote GitHub/site access. | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |
| 446 | .github/workflows/pages.yml | .github/workflows/pages.yml | KEEP | MEDIUM | Main/manual GitHub Pages pipeline: protected publisher check/build to _site, artifact upload and Pages deployment. | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |
| 447 | .github/workflows/playwright.yml | .github/workflows/playwright.yml | KEEP | MEDIUM | GitHub Actions Playwright journey/browser test setup, local-server execution and result artifacts. | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |
| 448 | .github/workflows/sheet-sync.yml | .github/workflows/sheet-sync.yml | KEEP | MEDIUM | Live Sheet bake and ordered tutor/site/index/editorial/inventory regeneration, followed by Git commit/push behavior. | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |

## Explicit KEEP list

| Current path (retained) | Reason |
|---|---|
| tools/APPS-SCRIPT-SETUP.md | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| tools/COPYRIGHT-DETECTION.md | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| tools/_countries-cache.json | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| tools/adminstats.js | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| tools/adsready.js | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/apply-country-seo.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/apply-country-specifics.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/apply-country-tutor-availability.js | Protected tutor/booking/feed behavior or public-roster output ownership. Preserve integration and generation contracts; no move proposed. |
| tools/apply-tutor-location-specifics.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/apply-ultra.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/apps-script-mailer.gs | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/apps-script-questions.gs | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/arabic-phase3-content/beginner.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/arabic-phase3-content/common-words.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/arabic-phase3-content/grammar.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/arabic-phase3-content/mistakes.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/arabic-phase3-content/numbers.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/arabic-phase3-content/pronunciation.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/arabic-phase3-content/reading.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/arabic-phase3-content/speaking-alone.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/arabic-phase3-content/travel.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/arabic-phase3-content/vs-hindi.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/assets/og-fonts/DejaVuSans-Bold.ttf | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| tools/assets/og-fonts/DejaVuSans.ttf | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| tools/assets/og-fonts/LICENSE-DejaVu.txt | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| tools/audit-adsense-readiness.py | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| tools/audit-course-pronunciation.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/audit-indian-topic-parity.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/audit-phase1-gap.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-all.py | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/build-combined-code.mjs | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/build-contextual-entry-links.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-copy-index.js | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| tools/build-country-language-pages.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-country-phrases.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-country-visuals.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-course-countries.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-course-hub.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-course-levels.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-flashcards.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-full-page-inventory.py | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| tools/build-guide-hreflang.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-hindi-foundation-depth.py | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| tools/build-hindi-hub.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-hindi-learning-library.py | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| tools/build-hindi-pages.py | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| tools/build-hindi-phrase-discovery.py | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| tools/build-hindi-quizzes.py | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| tools/build-hindi-structure.py | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| tools/build-home-tutors.js | Protected tutor/booking/feed behavior or public-roster output ownership. Preserve integration and generation contracts; no move proposed. |
| tools/build-inventory.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-join-schema.mjs | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/build-lang-topics.py | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| tools/build-language-course.py | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| tools/build-language-registry.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-learn-index.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-learning-data.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-legacy-pages.py | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| tools/build-legal-pages.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-market-pages.js | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-materials.py | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| tools/build-og-images.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-page-layer.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-phase2-content-inventory.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-phase3-originality-audit.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-phase7-pages.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-phase7-registries.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-phase7c-registries.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-print-sheets.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-public-dist.py | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/build-roster-rows.js | Protected tutor/booking/feed behavior or public-roster output ownership. Preserve integration and generation contracts; no move proposed. |
| tools/build-runtime.mjs | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/build-search-index.py | Publication/discovery contract: exact public-set, sitemap/robots, search-index and shared parser dependencies. Retain paths and scan behavior; no publisher or indexation change. |
| tools/build-seo-aeo-geo.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-shell.js | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-sitemaps.py | Publication/discovery contract: exact public-set, sitemap/robots, search-index and shared parser dependencies. Retain paths and scan behavior; no publisher or indexation change. |
| tools/build-themes.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-time-pages.py | Known Python/Node/file-based API or parameterized content dependency. A main-only wrapper would not establish equivalent import/module/side-effect semantics. |
| tools/build-toolbox-visuals.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-tutor-pages.js | Protected tutor/booking/feed behavior or public-roster output ownership. Preserve integration and generation contracts; no move proposed. |
| tools/build-ultra-pages.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-visuals.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-voice-languages.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-world-art.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-world-course.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/build-world-phase3.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/check-advertising-launch.mjs | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/check-search-index.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/course-data/ar.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/course-data/de.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/course-data/es.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/course-data/fr.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/course-data/it.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/course-data/ja.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/course-data/ko.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/course-data/pt.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/course-data/ru.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/course-data/zh.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/course-health.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/dedupe-script-tags.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/depth-content/ar.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/bn.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/de.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/es.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/fr.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/gu.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/it.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/ja.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/ko.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/mr.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/pa.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/pt.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/ru.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/ta.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/te.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/ur.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth-content/zh.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/depth_kit.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/discovery_integrity.py | Publication/discovery contract: exact public-set, sitemap/robots, search-index and shared parser dependencies. Retain paths and scan behavior; no publisher or indexation change. |
| tools/doctor.js | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| tools/gate.js | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| tools/german-phase3-content/beginner.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/german-phase3-content/common-words.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/german-phase3-content/grammar.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/german-phase3-content/mistakes.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/german-phase3-content/numbers.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/german-phase3-content/pronunciation.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/german-phase3-content/reading.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/german-phase3-content/speaking-alone.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/german-phase3-content/travel.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/german-phase3-content/vs-hindi.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/hi-b3-source/hi-b3-level.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/hi-b3-source/hi-b3-unit1.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/hi-b3-source/hi-b3-unit2.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/hi-b3-source/hi-b3-unit3.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/hindi-ext-content/c3.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/hindi-ext-content/c4.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/hindi-ext-content/c5.py | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/hindi-foundation-content.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/hindi-halfsteps-content.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/hindi-phase3-content.txt | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| tools/inject-ads.py | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/inject-consent.py | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/inject-flashcards.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/inject-questions-api.py | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/inject-storybook.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/lang-data/bengali.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/gujarati.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/kannada.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/malayalam.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/marathi.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/bn-education.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/bn-festivals.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/bn-health.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/bn-home.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/bn-office.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/bn-weather.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/gj-education.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/gj-festivals.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/gj-health.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/gj-home.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/gj-office.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/gj-weather.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/hi-education.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/hi-festivals.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/hi-health.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/hi-home.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/hi-office.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/hi-weather.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/kn-education.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/kn-festivals.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/kn-health.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/kn-home.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/kn-office.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/kn-weather.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ml-education.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ml-festivals.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ml-health.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ml-home.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ml-office.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ml-weather.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/mr-education.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/mr-festivals.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/mr-health.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/mr-home.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/mr-office.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/mr-weather.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/pj-education.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/pj-festivals.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/pj-health.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/pj-home.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/pj-office.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/pj-weather.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ta-education.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ta-festivals.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ta-health.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ta-home.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ta-office.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ta-weather.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/te-education.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/te-festivals.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/te-health.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/te-home.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/te-office.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/te-weather.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ur-education.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ur-festivals.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ur-health.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ur-home.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ur-office.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/modules/ur-weather.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/punjabi.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/tamil.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/telugu.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/lang-data/urdu.json | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/langpacks_194_af1.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/langpacks_194_af2.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/langpacks_194_af3.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/langpacks_194_as1.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/langpacks_194_as2.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/langpacks_194_eu1.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/langpacks_194_eu2.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/langpacks_194_eu3.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/langpacks_194_eu4.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/langpacks_194_oc1a.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/langpacks_194_oc1b.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/langpacks_194_oc2.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/langpacks_extra.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/langsync.js | Protected tutor/booking/feed behavior or public-roster output ownership. Preserve integration and generation contracts; no move proposed. |
| tools/language-gate.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/lib/__init__.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/appscript_health.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/bank_builder.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/country_quality.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/en_in.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/extended_banks.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/extended_banks_asia.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/extended_banks_batch2.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/extended_banks_batch3.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/extended_banks_batch4.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/extended_banks_batch5.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/extended_banks_batch6.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/extended_banks_core.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/extended_banks_rest.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/extended_banks_world.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/flashcard_section.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/hindi_learner_offer.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/placeholders.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/site-data.js | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/speech_tags.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/text.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/ultra_content.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/validate-language-schema.mjs | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/lib/zero-state.js | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/live-seo-gate.py | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| tools/make-tutor-row.py | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/materials_b.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/materials_c.py | Imported API or authored source bank, not proven stateless CLI infrastructure; retain module names, sys.path behavior, data provenance and source ownership. |
| tools/normalise-romanisation.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/patch-language-voice-controls.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/privacy.js | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| tools/probe-providers.py | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/quarantine-country-funnels.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/quarantine-language-surfaces.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/quarantine-tutor-drafts.py | Protected tutor/booking/feed behavior or public-roster output ownership. Preserve integration and generation contracts; no move proposed. |
| tools/repair-phase1-advanced-glosses.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/run-phase7c-pipeline.py | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/seocheck.js | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| tools/sheet-fetch.js | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/sheetsync.js | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/spanish-phase3-content/beginner.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/spanish-phase3-content/common-words.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/spanish-phase3-content/grammar.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/spanish-phase3-content/mistakes.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/spanish-phase3-content/numbers.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/spanish-phase3-content/pronunciation.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/spanish-phase3-content/reading.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/spanish-phase3-content/speaking-alone.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/spanish-phase3-content/travel.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/spanish-phase3-content/vs-hindi.html | Explicitly protected authored content/source subtree (133 files); identity mapping. Dynamic loaders are recorded, not relocated. |
| tools/templates/country-funnel-base.tmpl | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| tools/topic-meta.json | Existing source/template/license/documentation ownership; no demonstrated relocation benefit in this infrastructure-only tranche. |
| tools/trend-analysis.py | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| tools/ultra/contract.py | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| tools/update-editorial-metadata.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/validate-inventory.py | Registered master-pipeline tool with output/order/side-effect coupling; preserve CLI path and behavior. Further relocation requires a separate complete operational/API equivalence proof. |
| tools/weekly-guard.sh | Known diagnostic/workflow chain with report or live-service coupling; preserve registrations and existing exit/report semantics. Do not infer gate PASS from process exit 0. |
| tools/wire-token.py | Protected publishing/runtime/integration/orchestration interface or broad operational behavior; preserve fixed path and current behavior. |
| playwright.config.mjs | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |
| sw.js | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |
| package.json | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |
| .github/workflows/ci.yml | Retain workflow path and all existing commands/assertions. Only the explicit additive offline build-system compatibility test step is proposed; no service/dependency/deployment changes. |
| .github/workflows/course-health.yml | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |
| .github/workflows/live-guard.yml | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |
| .github/workflows/pages.yml | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |
| .github/workflows/playwright.yml | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |
| .github/workflows/sheet-sync.yml | Runtime/configuration registration contract; no change needed for the two proposed moves because legacy CLI paths remain supported. |

## Explicit DEFER list

| Current path (retained) | Reason |
|---|---|
| tools/audit-countries.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/audit-country-language-quality.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/audit-course-quality.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/audit-dark-contrast.mjs | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/audit-features.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/audit-generator-safety.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/audit-hindi-content.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/audit-local-http.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/audit-perf-a11y.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/audit-phase5-static.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/audit-runtime-errors.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/audit-site-pages.js | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/audit-srs.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/audit-voice.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/author-depth.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/author-hindi-advanced.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/author-hindi-extension.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/author-hindi-halfsteps.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/author-hindi-lessons.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/author-hindi-levels.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-country-funnel-pages.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-country-languages.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-courses.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-ekguru-final-reports.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-faq.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-global-pages.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-hindi-advanced.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-hindi-audio.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-hindi-classes-page.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-hindi-foundation.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-hindi-nav.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-hindi-phase3-posts.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-hindi-tutor-near-me-page.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-home-markets.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-lang-packs.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-language-course-matrix.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-learn.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-name-pages-nonindic.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-names-js.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-numbers-pages.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-phase7b-graph.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-phase7c-content-graph.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-say-pages.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-time-pages-bodies.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-topic-map.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/build-tutor-photo-variants.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/check-header-pages.mjs | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/check-header-pages.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/consolidate-header-css.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/contentguard.js | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/diag-header.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/dr-drill.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/enrich-tool-inventory.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/fix-country-clusters.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/fix-course-brackets.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/fix-seo-issues.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/freeze-baseline.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/generate-extended-courses.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/header-nav-cleanup.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/idle-live-final.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/indian-english.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/inject-advanced-seo.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/inject-modern.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/inject-recovery.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/learn-tools-audit.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/live-browser-matrix.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/live-crawl.js | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/live-monitor.js | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/live-perf.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/live-route-check.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/localise-speaker-labels.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-copyright-page.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-email-reports.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-email-ultra-reports.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-master-audit-fast.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-master-audit.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-p0-reports.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-phase2-reports.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-phase3-baseline.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-phase3-final.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-phase3-reports.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-phase4-reports.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-phase5-reports.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-requirements.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-requirements2.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/make-sweep-reports.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/measure-header.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/merge-email-requirements.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/merge-remaining-requirements.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/normalize-lang-data-classifiers.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/patch-header-css.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/phase2-baseline.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/phase3-dynamic-tests.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/phase3-security-scan.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/phase4-browser-gate.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/qa-perf-a11y.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/release-decision.js | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/render-og-images.mjs | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/render-report.js | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/repair-extended-levels.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/security-audit.js | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/sweep-header-geometry.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/unfreeze-country-languages.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/validate-sheets.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/verify-hindi-search.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/verify-hindi-typing.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/write-final-gate.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/write-phase6-reports.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/write-phase7-reports.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/write-phase7b-final.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/write-phase7c-reports.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/write-phase7c-reports2.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| tools/write-zero-hero-evidence.py | Known references, effects and static imports recorded, but a complete safe import/caller/operational contract is not demonstrated. Absence of a detected caller is not evidence of disuse. Keep current path pending separate proof. |
| docs/marketing/ekguru-brand-ad/scripts/assemble_veo_master.py | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| docs/marketing/ekguru-brand-ad/scripts/compose_music_and_mix.py | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| docs/marketing/ekguru-brand-ad/scripts/render_9x16_reel_shorts.py | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| docs/marketing/ekguru-brand-ad/scripts/render_brand_graphics.mjs | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| docs/marketing/ekguru-brand-ad/scripts/render_scene7_and_previz.py | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| docs/marketing/ekguru-social-campaign/scripts/build_all_in_one_post.py | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| docs/marketing/ekguru-social-campaign/scripts/prepare_framed_canvases.py | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| docs/marketing/ekguru-social-campaign/scripts/render_all_in_one_post.mjs | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| docs/marketing/ekguru-social-campaign/scripts/render_campaign_assets.mjs | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| docs/marketing/ekguru-social-campaign/scripts/shape_hindi_typography.py | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| docs/marketing/growth-distribution-2026-11/scripts/build_distribution_kit.js | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| docs/marketing/growth-distribution-2026-11/scripts/build_remaining_packs.js | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| docs/marketing/growth-distribution-2026-11/scripts/build_shorts_and_printables.py | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |
| docs/marketing/growth-distribution-2026-11/scripts/build_visual_assets.py | Campaign-local asset pipeline outside website build; environment-specific renderer/fonts/media inputs or sibling APIs need independent execution-environment audit. No proposed move. |

## All 22 existing launcher mappings (no new move)

| Retained launcher | Existing canonical test |
|---|---|
| tools/test-ad-policy.mjs | tests/regression/test-ad-policy.mjs |
| tools/test-adaptive-practice.js | tests/regression/test-adaptive-practice.js |
| tools/test-affiliate-disclosure.mjs | tests/regression/test-affiliate-disclosure.mjs |
| tools/test-application-backend.mjs | tests/integration/test-application-backend.mjs |
| tools/test-copy-index.mjs | tests/regression/test-copy-index.mjs |
| tools/test-course-levels.mjs | tests/regression/test-course-levels.mjs |
| tools/test-email-security.js | tests/integration/test-email-security.js |
| tools/test-email-system.js | tests/integration/test-email-system.js |
| tools/test-join-css-visibility.mjs | tests/regression/test-join-css-visibility.mjs |
| tools/test-join-wizard-nav.mjs | tests/regression/test-join-wizard-nav.mjs |
| tools/test-join-wizard.mjs | tests/regression/test-join-wizard.mjs |
| tools/test-live-feed.js | tests/integration/test-live-feed.js |
| tools/test-question-api.mjs | tests/regression/test-question-api.mjs |
| tools/test-reviews-fallback.js | tests/integration/test-reviews-fallback.js |
| tools/test-routing.js | tests/integration/test-routing.js |
| tools/test-sheet-fetch.mjs | tests/integration/test-sheet-fetch.mjs |
| tools/test-sheet-only-bake.mjs | tests/integration/test-sheet-only-bake.mjs |
| tools/test-support-static.mjs | tests/regression/test-support-static.mjs |
| tools/test-theme-contrast.mjs | tests/regression/test-theme-contrast.mjs |
| tools/test-tools-functional.py | tests/regression/test-tools-functional.py |
| tools/test-tutor-activation.mjs | tests/integration/test-tutor-activation.mjs |
| tools/test-usability-home.mjs | tests/regression/test-usability-home.mjs |

## All package script registrations (unchanged)

- **start**: `node server/server.js`
- **test**: `node tests/integration/test-razorpay-api.mjs && node tests/regression/test-join-wizard.mjs && node tests/integration/test-application-backend.mjs && node tests/regression/test-defect-regressions.mjs && node tests/integration/test-wizard-sheets-e2e.mjs && node tests/regression/test-join-css-visibility.mjs && node tests/regression/test-join-wizard-nav.mjs && node tests/integration/test-application-pipeline.mjs && node tests/integration/test-combined-code.mjs && node tests/regression/test-browser-qa.mjs && node tests/regression/test-runtime-qa.mjs && node tests/integration/test-apps-script.mjs && node tests/integration/test-payment-e2e.mjs && node tests/integration/test-live-payment-contract.mjs && node tests/regression/test-home-tutor-reveal.mjs && node tests/regression/test-home-practice.mjs && node tests/regression/test-analytics-lifecycle.mjs && node tests/regression/test-script-map.mjs && node tests/integration/test-live-feed.js`
- **test:learners**: `node tests/regression/test-learner-trust.mjs && node tests/regression/test-name-share-privacy.mjs && node tests/regression/test-name-page.mjs`
- **test:analytics**: `node tests/regression/test-analytics-lifecycle.mjs && node tests/regression/test-consent-release.mjs`
- **test:payments**: `node tests/integration/test-razorpay-api.mjs`
- **test:qa**: `node tests/regression/test-browser-qa.mjs`
- **test:sheets**: `node tests/integration/test-apps-script.mjs`
- **test:e2e**: `node tests/integration/test-payment-e2e.mjs`
- **test:contract**: `node tests/integration/test-live-payment-contract.mjs`
- **test:course-reorder**: `node tests/regression/test-course-reorder.mjs`
- **test:courses**: `node tests/regression/test-course-placeholders.mjs && node tests/regression/test-course-levels.mjs && python3 tests/regression/test-course-voice-buttons.py && python3 tools/audit-course-pronunciation.py --check && node tests/regression/test-course-matching.mjs && node tests/regression/test-course-reorder.mjs`
- **test:home**: `node tests/regression/test-home-tutor-reveal.mjs && node tests/regression/test-home-practice.mjs && node tests/regression/test-menu-search.mjs`
- **test:monetization**: `node tests/regression/test-monetization-disclosures.mjs && node tests/regression/test-name-card.mjs && node tests/regression/test-adsready-diagnostics.mjs`
- **test:advertising**: `node tests/regression/test-advertising-launch.mjs && node tests/regression/test-consent-release.mjs && node tests/regression/test-ad-policy.mjs`
- **advertising:status**: `node tools/check-advertising-launch.mjs`
- **advertising:check**: `node tools/check-advertising-launch.mjs --check`
- **test:browser**: `node tests/e2e/test-join-buttons-browser.mjs`

## Audit preservation and coverage results

```json
{
  "checks": {
    "coverage_tools_exact": true,
    "coverage_unique_448": true,
    "protected_exact_133": true,
    "only_two_moves": true,
    "all_retained_paths_identity": true,
    "all_destinations_private_by_literal_policy": true,
    "all_22_launcher_targets_exist": true,
    "all_6627_repo_hashes_unchanged": true,
    "git_status_exact_bytes_unchanged": true,
    "branch_unchanged": true,
    "head_unchanged": true
  },
  "changed_repository_paths": [],
  "tracked_and_untracked_files_hashed": 6627,
  "status_counts": {
    " M": 127,
    " D": 175,
    "??": 203
  },
  "note": "These PASS checks establish audit artifact coverage and repository preservation only. No application/build/workflow/test was executed."
}
```
